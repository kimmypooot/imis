-- Dumping table structure for `psed_annual_ld`

CREATE TABLE `psed_annual_ld` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `psed_annual_year` varchar(12) NOT NULL,
  `psed_annual_nohours` varchar(12) NOT NULL,
  `psed_annual_type` varchar(64) NOT NULL,
  `psed_annual_nametrng` varchar(512) NOT NULL,
  `psed_annual_perstrng` varchar(512) NOT NULL,
  `psed_annual_conducted` varchar(512) NOT NULL,
  `psed_annual_file` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `psed_annual_ld` is empty

