-- Dumping table structure for `psed_report_schedules`

CREATE TABLE `psed_report_schedules` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `type_report` varchar(512) NOT NULL,
  `frequency` varchar(512) NOT NULL,
  `deadline` varchar(512) NOT NULL,
  `prepared_by` varchar(512) NOT NULL,
  `submitted_to` varchar(512) NOT NULL,
  `remarks` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `psed_report_schedules`

INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('1', 'Enhanced Monthly Report on Appointments Processed (MRAP)', 'Monthly', 'Every 1st day of the succeeding month', 'CSC Field and Satellite Offices', 'PSED', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('2', 'Integrated Performance Monitoring Report (IPMR)', 'Monthly', 'Every 1st day of the succeeding month', 'CSC Field and Satellite Offices', 'PSED', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('3', 'Monitoring on Appointments (MOA)', 'Monthly', 'Every 1st day of the succeeding month', 'CSC Field and Satellite Offices', 'PSED', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('4', 'PRIME-HRM Monthly Accomplishment Report on Assessment', 'Monthly', 'Every 1st day of the succeeding month', 'CSC Field and Satellite Offices', 'PSED', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('5', 'PRIME-HRM CSC FO Assistance Plan Progress Log', 'Quarterly', 'Every 1st day of the succeeding quarter', 'CSC Field and Satellite Offices', 'PSED', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('6', 'FO Inventory of Government Human Resources (IGHR) Certificate of Compliance', 'Annually', 'Depending on the deadline set by the CSC RO thru PSED per ROM', 'CSC Field and Satellite Offices', 'PSED', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('7', 'PSED Integrated Performance Monitoring Report (IPMR)', 'Monthly', 'Every 4th day of the succeeding month', 'PSED', 'PALD', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('8', 'PSED Inventory of Cases (Legal Opinion)', 'Monthly', 'Every 1st day of the succeeding month', 'PSED', 'LSD', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('9', 'PSED Integrated Performance Monitoring Sheet (IPMS)', 'Monthly', 'Every 1st day of the succeeding month', 'PSED', 'LSD', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('10', 'Minutes of the Interposed Activity', 'Every after hosting', 'Within 15 days from the hosting and conduct of interposed activity', 'PSED', 'PALD', 'per CSC RO VIII ROM No. 30, s. 2023 dated 28 December 2023');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('11', 'Minutes of the Management Committee Meeting, Change Management Committee Meeting & Quality Management System Review', 'Every after hosting', 'Within 15 days from the hosting and conduct of activity/meeting', 'PSED', 'PALD', 'per CSC RO VIII ROM No. 29, s. 2023 dated 29 December 2023');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('12', 'Quarterly Report on the conduct of Happy, Healthy, Active People Year-Round (HHAPY) Hour ', 'Quarterly', 'Not specified in CSC RO VIII ROM No. 48, s. 2023 dated 2 February 2023', 'PSED', 'HRD', 'per CSC RO VIII ROM No. 48, s. 2023 dated 2 February 2023');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('13', 'Inventory of Records Holding', 'Annually', 'Depending on the deadline set by the CSC RO thru MSD per ROM', 'PSED', 'MSD', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('14', 'Program Review and Analysis (Annual Accomplishment Report)', 'Annually', 'Depending on the deadline set by the CSC RO thru MSD per ROM', 'PSED', 'ORD', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('15', 'Project Procurement Management Plan', 'Annually', 'Depending on the deadline set by the CSC RO thru MSD per ROM', 'PSED', 'MSD', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('16', 'Quarterly Economy Measures Report', 'Quarterly', 'Every 3rd day of the succeeding quarter', 'PSED', 'MSD', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('17', 'PSED PRIME-HRM Monthly Accomplishment Report on Assessment', 'Monthly', 'Every 6th day of the succeeding month', 'CSC RO thru PSED', 'HRPSO', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('18', 'Quarterly Report on PRIME-HRM Assistance and Award', 'Quarterly', 'Every 6th day of the succeeding quarter', 'CSC RO thru PSED', 'HRPSO', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('19', 'PRIME-HRM Monthly Reportorial Requirements:a. Number of agencies meeting Maturity Level 2, 3, or 4 in all HR areas (Bronze, Silver and Gold Award)b. Number of agencies meeting Maturity Level 2 in RSP and PM (Accreditation Award)c. Number of HRM systerms recognized (Recognition)', 'Monthly', 'Every 10th working day (WD) of the succeeding month', 'CSC RO thru PSED', 'HRPSO', 'per HRPSO Memo No. 043, s. 2024 (2024 PRIME-HRM Reports)');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('20', 'CSC RO Inventory of Government Human Resources (IGHR) Certificate of Compliance', 'Annually', 'Depending on the deadline set by the IRMO for the given year', 'CSC RO thru PSED', 'IRMO', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('21', 'Report of Plan of Action', 'Annually', 'Within 15 days from receipt of IAS Audit Report of Findings', 'CSC RO thru PSED', 'IAS', '');
INSERT INTO `psed_report_schedules` (`id`, `type_report`, `frequency`, `deadline`, `prepared_by`, `submitted_to`, `remarks`) VALUES ('22', 'Report of Effectiveness', 'Annually', 'Within six (6) months after termination of the IAS Audit', 'CSC RO VIII thru PSED', 'IAS', '');

