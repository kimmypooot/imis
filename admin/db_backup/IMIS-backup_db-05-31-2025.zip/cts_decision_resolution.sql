-- Dumping table structure for `cts_decision_resolution`

CREATE TABLE `cts_decision_resolution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_decision_resolution`

INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('1', 'Administrative Charges/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('2', 'Administrative Investigation/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('3', 'Answer');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('4', 'Appeal/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('5', 'Appeal/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('6', 'Appeal/Moot & Academic');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('7', 'Appeal/Partly Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('8', 'Appeal/Withdrawn');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('9', 'Case/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('10', 'Case/Referred to Agency');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('11', 'Case/Remanded to Agency');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('12', 'Case/Remanded to CSCROs');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('13', 'Complaint/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('14', 'Directed to explain in writing why should not be cited for indirect contempt');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('15', 'Exonerated');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('16', 'Formal Charge');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('17', 'Guilty');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('18', 'Indirect Contempt Charge/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('19', 'Manifestation/Noted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('20', 'Motion/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('21', 'Motion/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('22', 'Motion for Clarification/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('23', 'Motion for Clarification/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('24', 'Motion for Clarification/Partially Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('25', 'Motion for Conversion of Penalty of Suspension to Fine/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('26', 'Motion for Conversion of Penalty of Suspension to Fine/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('27', 'Motion for Deferment/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('28', 'Motion for Deferment/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('29', 'Motion for Execution or Implementation/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('30', 'Motion for Execution or Implementation/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('31', 'Motion for Execution or Implementation/Moot & Academic');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('32', 'Motion for Execution or Implementation/Partly Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('33', 'Motion for Exoneration/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('34', 'Motion for Exoneration/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('35', 'Motion for Partial Reconsideration/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('36', 'Motion for Partial Reconsideration/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('37', 'Motion for Preventive Suspension/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('38', 'Motion for Preventive Suspension/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('39', 'Motion for Preventive Suspension/Moot & Academic');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('40', 'Motion for Reconsideration/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('41', 'Motion for Reconsideration/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('42', 'Motion for Reconsideration/Partially Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('43', 'Motion for Suspension of Proceedings/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('44', 'Motion for Suspension of Proceedings/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('45', 'Motion for Withdrawal/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('46', 'Motion for Withdrawal/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('47', 'Motion to Dismiss/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('48', 'Motion to Dismiss/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('49', 'Motion to Inhibit/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('50', 'Motion to Inhibit/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('51', 'Petition/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('52', 'Petition/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('53', 'Petition or Motion for Indirect Contempt/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('54', 'Petition or Motion for Indirect Contempt/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('55', 'Petition for Review/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('56', 'Petition for Review/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('57', 'Petition for Review/Partially Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('58', 'Protest/Dismissed');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('59', 'Protest/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('60', 'Report of Investigation');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('61', 'Request/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('62', 'Request/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('63', 'Request/Noted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('64', 'Request/Partly Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('65', 'Request for Transfer of Venue/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('66', 'Request for Transfer of Venue/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('67', 'Second Motion for Reconsideration/Denied');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('68', 'Second Motion for Reconsideration/Granted');
INSERT INTO `cts_decision_resolution` (`id`, `category_name`) VALUES ('69', 'Replied');

