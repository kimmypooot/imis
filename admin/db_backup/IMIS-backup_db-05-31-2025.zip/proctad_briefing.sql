-- Dumping table structure for `proctad_briefing`

CREATE TABLE `proctad_briefing` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ta_id` int(12) NOT NULL,
  `testing_center` int(12) NOT NULL,
  `time_in` varchar(11) DEFAULT NULL,
  `logdate` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_briefing_center` (`testing_center`),
  CONSTRAINT `fk_briefing_center` FOREIGN KEY (`testing_center`) REFERENCES `proctad_fo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_briefing`

INSERT INTO `proctad_briefing` (`id`, `ta_id`, `testing_center`, `time_in`, `logdate`) VALUES ('8', '10', '1', '02:43:49 PM', '2025-05-19');
INSERT INTO `proctad_briefing` (`id`, `ta_id`, `testing_center`, `time_in`, `logdate`) VALUES ('9', '1', '1', '02:57:52 PM', '2025-05-19');
INSERT INTO `proctad_briefing` (`id`, `ta_id`, `testing_center`, `time_in`, `logdate`) VALUES ('10', '58', '1', '04:10:41 PM', '2025-05-20');
INSERT INTO `proctad_briefing` (`id`, `ta_id`, `testing_center`, `time_in`, `logdate`) VALUES ('11', '38', '1', '02:50:28 PM', '2025-05-22');
INSERT INTO `proctad_briefing` (`id`, `ta_id`, `testing_center`, `time_in`, `logdate`) VALUES ('12', '10', '2', '09:31:05 PM', '2025-05-22');

