-- Dumping table structure for `ors_rating`

CREATE TABLE `ors_rating` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `applicant_id` int(12) NOT NULL,
  `twe_rating` varchar(12) NOT NULL,
  `twe_status` varchar(12) NOT NULL,
  `cbwe_rating` varchar(12) NOT NULL,
  `cbwe_status` varchar(12) NOT NULL,
  `bei_core_ei` varchar(12) NOT NULL,
  `bei_core_spdm` varchar(12) NOT NULL,
  `bei_core_dse` varchar(12) NOT NULL,
  `bei_org_cai` varchar(12) NOT NULL,
  `bei_org_pd` varchar(12) NOT NULL,
  `bei_org_dpe` varchar(12) NOT NULL,
  `bei_org_se` varchar(12) NOT NULL,
  `bei_org_we` varchar(12) NOT NULL,
  `bei_org_mi` varchar(12) NOT NULL,
  `bei_leader_mp` varchar(12) NOT NULL,
  `bei_leader_bc` varchar(12) NOT NULL,
  `bei_leader_dp` varchar(12) NOT NULL,
  `bei_leader_ts` varchar(12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `applicant_id` (`applicant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `ors_rating`

INSERT INTO `ors_rating` (`id`, `applicant_id`, `twe_rating`, `twe_status`, `cbwe_rating`, `cbwe_status`, `bei_core_ei`, `bei_core_spdm`, `bei_core_dse`, `bei_org_cai`, `bei_org_pd`, `bei_org_dpe`, `bei_org_se`, `bei_org_we`, `bei_org_mi`, `bei_leader_mp`, `bei_leader_bc`, `bei_leader_dp`, `bei_leader_ts`) VALUES ('1', '1', '85', 'Pass', '90', 'Pass', '75', '80', '70', '85', '88', '82', '75', '90', '78', '85', '80', '83', '80');
INSERT INTO `ors_rating` (`id`, `applicant_id`, `twe_rating`, `twe_status`, `cbwe_rating`, `cbwe_status`, `bei_core_ei`, `bei_core_spdm`, `bei_core_dse`, `bei_org_cai`, `bei_org_pd`, `bei_org_dpe`, `bei_org_se`, `bei_org_we`, `bei_org_mi`, `bei_leader_mp`, `bei_leader_bc`, `bei_leader_dp`, `bei_leader_ts`) VALUES ('2', '2', '88', 'Pass', '92', 'Pass', '78', '82', '72', '87', '90', '84', '78', '92', '80', '88', '83', '85', '83');

