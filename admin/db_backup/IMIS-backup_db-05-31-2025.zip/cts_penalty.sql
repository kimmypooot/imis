-- Dumping table structure for `cts_penalty`

CREATE TABLE `cts_penalty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `penalty_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_penalty`

INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('1', 'CS Professional Eligibility/Cancelled');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('2', 'CS Sub-Professional Eligibility/Cancelled');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('3', 'Demotion (next lower position or diminution of salary to next lower grade)');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('4', 'Dismissal from the Service');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('5', 'Dropped from the Rolls');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('6', 'Fine equivalent to five (5) months salary');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('7', 'Fine equivalent to four (4) months salary');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('8', 'Fine equivalent to one (1) month salary');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('9', 'Fine equivalent to six (6) months salary');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('10', 'Fine equivalent to three (3) months salary');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('11', 'Fine equivalent to two (2) months salary');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('12', 'Fine of P1,000.00 for every day of non-implementation');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('13', 'Preventive Suspension');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('14', 'Preventive Suspension for 30 days');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('15', 'Preventive Suspension for 60 days');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('16', 'Preventive Suspension for 90 days');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('17', 'Reprimand');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('18', 'Suspension from the Service for one (1) year');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('19', 'Suspension from the Service for fifteen (15) days');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('20', 'Suspension from the Service for nine (9) months');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('21', 'Suspension from the Service for nine (9) months and one (1) day');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('22', 'Suspension from the Service for one (1) month and one (1) day');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('23', 'Suspension from the Service for six (6) months');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('24', 'Suspension from the Service for six (6) months and one (1) day');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('25', 'Suspension from the Service for thirty (30) days or one (1) month');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('26', 'Suspension from the Service for three (3) months');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('27', 'Suspension from the Service for three (3) months and one (1) day');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('28', 'Suspension from the Service for two (2) months');
INSERT INTO `cts_penalty` (`id`, `penalty_name`) VALUES ('29', 'Terminated from the Service');

