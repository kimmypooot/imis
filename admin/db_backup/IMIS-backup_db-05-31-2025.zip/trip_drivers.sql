-- Dumping table structure for `trip_drivers`

CREATE TABLE `trip_drivers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_csc_users` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `trip_drivers`

INSERT INTO `trip_drivers` (`id`, `user`, `status`, `timestamp`) VALUES ('5', '5', 'Available', '2025-05-19 02:28:52');
INSERT INTO `trip_drivers` (`id`, `user`, `status`, `timestamp`) VALUES ('6', '1', 'Available', '2025-05-19 05:54:47');
INSERT INTO `trip_drivers` (`id`, `user`, `status`, `timestamp`) VALUES ('7', '3', 'Available', '2025-05-19 06:02:01');
INSERT INTO `trip_drivers` (`id`, `user`, `status`, `timestamp`) VALUES ('8', '52', 'Available', '2025-05-23 06:35:38');
INSERT INTO `trip_drivers` (`id`, `user`, `status`, `timestamp`) VALUES ('9', '9', 'Available', '2025-05-28 06:55:28');

