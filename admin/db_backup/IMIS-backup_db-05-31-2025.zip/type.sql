-- Dumping table structure for `type`

CREATE TABLE `type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(12) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `type`

INSERT INTO `type` (`id`, `type`, `timestamp`) VALUES ('1', 'admin', '2025-03-03 06:14:34');
INSERT INTO `type` (`id`, `type`, `timestamp`) VALUES ('2', 'user', '2025-03-03 06:14:34');

