-- Dumping table structure for `cdl_csc_divisions`

CREATE TABLE `cdl_csc_divisions` (
  `cdl_csc_division_id` int(11) NOT NULL AUTO_INCREMENT,
  `cdl_csc_division_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cdl_csc_division_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `cdl_csc_divisions`

INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('1', 'Human Resource Division');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('2', 'Public Assistance and Liaison Division');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('3', 'Examination Services Division');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('4', ' Policies and Systems Evaluation Division');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('5', 'Management Services Division');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('6', 'Anti Red Tape Unit');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('7', 'CSC Field Office - Leyte I');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('8', 'Legal Services Division');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('9', 'CSC Field Office - Leyte II');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('10', 'CSC Field Office - Biliran');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('11', 'CSC Field Office - Southern Leyte');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('12', 'CSC Field Office - Samar');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('13', 'CSC Field Office - Eastern Samar');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('14', 'CSC Field Office - Northern Samar');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('15', 'CSC Satellite Office - Western Leyte');
INSERT INTO `cdl_csc_divisions` (`cdl_csc_division_id`, `cdl_csc_division_name`) VALUES ('16', 'Office of the Regional Director');

