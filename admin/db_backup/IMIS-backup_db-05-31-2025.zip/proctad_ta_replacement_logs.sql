-- Dumping table structure for `proctad_ta_replacement_logs`

CREATE TABLE `proctad_ta_replacement_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_ta_id` int(11) NOT NULL,
  `replacement_ta_id` int(11) NOT NULL,
  `exam_type_id` int(12) NOT NULL,
  `exam_date_id` int(12) NOT NULL,
  `testing_center_id` int(12) NOT NULL,
  `reason` text NOT NULL,
  `action_officer` varchar(124) NOT NULL,
  `replaced_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_ta_replacement_logs`

INSERT INTO `proctad_ta_replacement_logs` (`id`, `original_ta_id`, `replacement_ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `reason`, `action_officer`, `replaced_at`) VALUES ('1', '1', '58', '0', '0', '1', '1st testing', 'mfcadiz', '2025-05-22 11:25:22');
INSERT INTO `proctad_ta_replacement_logs` (`id`, `original_ta_id`, `replacement_ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `reason`, `action_officer`, `replaced_at`) VALUES ('2', '1', '58', '0', '0', '0', '11', 'mfcadiz', '2025-05-22 11:56:01');
INSERT INTO `proctad_ta_replacement_logs` (`id`, `original_ta_id`, `replacement_ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `reason`, `action_officer`, `replaced_at`) VALUES ('3', '1', '58', '3', '2', '0', 'Weaaaaa', 'mfcadiz', '2025-05-22 12:58:24');
INSERT INTO `proctad_ta_replacement_logs` (`id`, `original_ta_id`, `replacement_ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `reason`, `action_officer`, `replaced_at`) VALUES ('4', '58', '1', '1', '1', '0', 'waaa', 'mfcadiz', '2025-05-22 12:59:16');
INSERT INTO `proctad_ta_replacement_logs` (`id`, `original_ta_id`, `replacement_ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `reason`, `action_officer`, `replaced_at`) VALUES ('5', '1', '58', '3', '2', '1', 'March 9', 'mfcadiz', '2025-05-22 13:04:35');
INSERT INTO `proctad_ta_replacement_logs` (`id`, `original_ta_id`, `replacement_ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `reason`, `action_officer`, `replaced_at`) VALUES ('6', '1', '58', '3', '2', '1', 'Unexpected chuchu', 'mfcadiz', '2025-05-22 13:08:15');

