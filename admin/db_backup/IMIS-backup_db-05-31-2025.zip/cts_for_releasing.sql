-- Dumping table structure for `cts_for_releasing`

CREATE TABLE `cts_for_releasing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `addressee` varchar(255) DEFAULT NULL,
  `office_address` text DEFAULT NULL,
  `rrr_no` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `date_received` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_case_id` (`case_id`),
  CONSTRAINT `fk_case_id` FOREIGN KEY (`case_id`) REFERENCES `cts_manage_case` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_for_releasing`

INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('9', '9', NULL, NULL, NULL, '2025-05-08 01:16:35', '2025-05-08 01:16:35', NULL);
INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('10', '10', NULL, NULL, NULL, '2025-05-30 06:13:43', '2025-05-30 06:13:43', NULL);
INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('11', '11', NULL, NULL, NULL, '2025-05-30 07:09:32', '2025-05-30 07:09:32', NULL);
INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('12', '12', NULL, NULL, NULL, '2025-05-30 15:01:21', '2025-05-30 15:01:21', NULL);
INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('13', '13', NULL, NULL, NULL, '2025-05-30 15:02:33', '2025-05-30 15:02:33', NULL);
INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('14', '14', NULL, NULL, NULL, '2025-05-30 15:03:56', '2025-05-30 15:03:56', NULL);
INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('15', '15', NULL, NULL, NULL, '2025-05-30 15:04:56', '2025-05-30 15:04:56', NULL);
INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('16', '16', NULL, NULL, NULL, '2025-05-30 15:08:54', '2025-05-30 15:08:54', NULL);
INSERT INTO `cts_for_releasing` (`id`, `case_id`, `addressee`, `office_address`, `rrr_no`, `created_at`, `updated_at`, `date_received`) VALUES ('17', '17', NULL, NULL, NULL, '2025-05-30 15:14:31', '2025-05-30 15:14:31', NULL);

