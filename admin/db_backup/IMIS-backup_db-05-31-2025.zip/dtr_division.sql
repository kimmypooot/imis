-- Dumping table structure for `dtr_division`

CREATE TABLE `dtr_division` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `division_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `dtr_division`

INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('1', 'Human Resource Division');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('2', 'Public Assistance and Liaison Division');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('3', 'Examination Services Division');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('4', ' Policies and Systems Evaluation Division');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('5', 'Office of the Regional Director');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('6', 'Management Services Division');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('7', 'CSC Field Office - Leyte I');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('8', 'CSC Field Office - Leyte II');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('9', 'Legal Services Division');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('10', 'CSC Field Office - Biliran');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('11', 'CSC Field Office - Southern Leyte');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('12', 'CSC Field Office - Samar');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('13', 'CSC Field Office - Eastern Samar');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('14', 'CSC Field Office - Northern Samar');
INSERT INTO `dtr_division` (`id`, `division_name`) VALUES ('15', 'CSC Field Office - Western Leyte');

