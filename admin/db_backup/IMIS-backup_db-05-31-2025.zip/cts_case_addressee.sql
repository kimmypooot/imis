-- Dumping table structure for `cts_case_addressee`

CREATE TABLE `cts_case_addressee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `addressee` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_case_addressee`

INSERT INTO `cts_case_addressee` (`id`, `case_id`, `addressee`, `timestamp`) VALUES ('31', '9', '20', '2025-05-08 03:17:20');
INSERT INTO `cts_case_addressee` (`id`, `case_id`, `addressee`, `timestamp`) VALUES ('32', '9', '17', '2025-05-08 03:17:31');
INSERT INTO `cts_case_addressee` (`id`, `case_id`, `addressee`, `timestamp`) VALUES ('33', '11', '2', '2025-05-30 14:39:53');

