-- Dumping table structure for `collecting_officer`

CREATE TABLE `collecting_officer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `position` varchar(64) NOT NULL,
  `location` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `collecting_officer`

INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('2', 'Richmond A. Sanglay', 'Senior Human Resource Specialist', 'SLFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('4', 'Jay M. Merelos', 'Chief Human Resource Specialist', 'HRD');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('5', 'Kim Benedick M. Banoyo', 'Administrative Assistant II', 'HRD');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('6', 'Lucille K. Lepasana', 'Supervising Human Resource Specialist', 'SFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('7', 'Benjie M. Gelizon', 'Supervising Human Resource Specialist', 'BFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('9', 'Rey Albert B. Uy', 'Director II', 'ESFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('10', 'Bonita T. Arcelo', 'Senior Human Resource Specialist', 'WLSO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('11', 'Michael M. Dela Cruz', 'Director II', 'WLSO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('12', 'Jason Thaddeus A. Tan', 'Supervising Human Resource Specialist', 'ESFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('13', 'Mark Jacob L. De Paz', 'Human Resource Specialist I', 'ESFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('14', 'Pharida Q. Aurelia', 'Director II', 'LFOII');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('15', 'Ma. Natividad L. Costibolo', 'Director II', 'LFOI');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('16', 'Marjorie Anne F. Cadiz', 'Supervising Human Resource Specialist', 'LFOI');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('18', 'Don Mark Phillipe D. de los Reyes', 'Senior Human Resource Specialist', 'LFOII');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('20', 'Rogelio B. Ramos', 'Senior Human Resource Specialist', 'LFOI');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('24', 'Vicente C. Tolosa', 'Senior Human Resource Specialist', 'LFOII');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('27', 'Charl G. Pabillon', 'Supervising Human Resource Specialist', 'NSFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('28', 'Michael M. Dela Cruz', 'Director II', 'BFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('29', 'Rey Albert B. Uy', 'Director II', 'SFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('30', 'Hector R. Felix', 'Senior Human Resource Specialist', 'RO7');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('31', 'Joelyn Marie L. Toraballa', 'Human Resource Specialist I', 'RO6');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('32', 'Leo F. Jamorin', 'Director II', 'RO6');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('33', 'Andre L. Ladigohon', 'Director II', 'RO6');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('34', 'Vizur-Ty C. Gaitano', 'Director II', 'RO6');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('35', 'John Esar T. David', 'Director II', 'RO6');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('36', 'Phillip Bernard H. Capadosa', 'Director II', 'RO6');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('37', 'Ricardo I. Gabule Jr.', 'Senior Human Resource Specialist', 'RO7');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('38', 'Violita A. Bagsarsa', 'Administrative Assistant III', 'RO7');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('39', 'Alice May S. Parcon', 'Director II', 'RO7');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('40', 'Zerah Eliez C. Sanchez', 'Human Resource Specialist II', 'RO7');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('41', 'Genivive S. Cristuta', 'Supervising Human Resource Specialist', 'RO7');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('42', 'Cerise D. Versoza', 'Director II', 'SLFO');
INSERT INTO `collecting_officer` (`id`, `name`, `position`, `location`) VALUES ('44', 'Ma. Lourdes D. Sabalza', 'Senior Human Resource Specialist', 'LFOII');

