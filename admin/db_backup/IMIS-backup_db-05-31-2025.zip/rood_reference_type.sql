-- Dumping table structure for `rood_reference_type`

CREATE TABLE `rood_reference_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_name` varchar(256) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `rood_reference_type`

INSERT INTO `rood_reference_type` (`id`, `reference_name`, `timestamp`) VALUES ('1', 'Competency-Based Recruitment and Promotion Issuances', '2025-04-25 07:41:13');
INSERT INTO `rood_reference_type` (`id`, `reference_name`, `timestamp`) VALUES ('2', 'Policies on Alternative Work Arrangements (AWA)', '2025-04-25 07:41:30');
INSERT INTO `rood_reference_type` (`id`, `reference_name`, `timestamp`) VALUES ('3', 'Policies on Attendance and Leave Administration', '2025-04-25 07:41:38');
INSERT INTO `rood_reference_type` (`id`, `reference_name`, `timestamp`) VALUES ('4', 'Regional Office Memorandum', '2025-04-28 03:36:10');
INSERT INTO `rood_reference_type` (`id`, `reference_name`, `timestamp`) VALUES ('5', 'Regional Office Orders', '2025-04-28 03:36:33');
INSERT INTO `rood_reference_type` (`id`, `reference_name`, `timestamp`) VALUES ('6', 'Training Related Issuances', '2025-04-28 03:35:23');
INSERT INTO `rood_reference_type` (`id`, `reference_name`, `timestamp`) VALUES ('7', 'Welfare Fund and Employees Benefits Related Issuances', '2025-04-28 03:35:32');
INSERT INTO `rood_reference_type` (`id`, `reference_name`, `timestamp`) VALUES ('8', 'NOT IN USE', '2025-04-25 05:48:46');

