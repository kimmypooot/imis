-- Dumping table structure for `dtr_moa`

CREATE TABLE `dtr_moa` (
  `id` int(11) NOT NULL,
  `universities` int(11) NOT NULL,
  `moa` varchar(255) NOT NULL,
  `date_valid_from` date NOT NULL,
  `date_valid_to` date NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_moa_university` (`universities`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `dtr_moa` is empty

