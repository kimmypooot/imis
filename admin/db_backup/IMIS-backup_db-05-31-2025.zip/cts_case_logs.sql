-- Dumping table structure for `cts_case_logs`

CREATE TABLE `cts_case_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `cts_ao_assign_log_ibfk_1` (`case_id`),
  CONSTRAINT `cts_case_logs_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cts_manage_case` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_case_logs`

INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('49', '9', 'New Case Received: Simple Misconduct - Lorenz Gabriel Sabalza', 'Received', '2025-05-08 09:16:35');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('50', '9', 'Case Update: Case is being assigned to 437-C (Lorenz Gabriel Sabalza)', 'Assigning', '2025-05-08 09:31:49');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('51', '9', 'Case Update: 437-C has received the document and has been assigned to this case', 'Pending', '2025-05-08 10:58:30');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('52', '9', 'Drafted', 'Pending', '2025-05-08 11:04:17');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('53', '9', 'Case Update: Case has been moved to Post-Decision Actions.', 'Post-Pending', '2025-05-08 11:04:38');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('54', '9', 'Case Update: Case has been resolved', 'Resolved', '2025-05-08 11:05:00');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('55', '9', 'Case Update: Case status has been update to "For Releasing"', 'For Releasing', '2025-05-08 11:09:11');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('56', '10', 'New Case Received: Abuse of Authority - Harold Ian Sablawon', 'Received', '2025-05-30 06:13:43');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('57', '10', 'Case Update: Case is being assigned to 427-S (Flordeliza Algas)', 'Assigning', '2025-05-30 06:27:22');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('58', '11', 'New Case Received: Reversion to Use of Maiden Name in the Personnel Records - Mark Kian Tisado', 'Received', '2025-05-30 07:09:32');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('59', '11', 'Case Update: Case is being assigned to 437-A (Jonalyn Sumayod)', 'Assigning', '2025-05-30 07:15:22');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('60', '11', 'Case Update: 437-A has received the document and has been assigned to this case', 'Pending', '2025-05-30 07:15:38');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('61', '11', 'Case Update: Case has been moved to Post-Decision Actions.', 'Post-Pending', '2025-05-30 07:43:53');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('62', '11', 'Case Update: Case has been resolved', 'Resolved', '2025-05-30 14:39:17');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('63', '11', 'Case Update: Case status has been update to "For Releasing"', 'For Releasing', '2025-05-30 14:39:32');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('64', '12', 'New Case Received: Basta - John Doe', 'Received', '2025-05-30 15:01:21');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('65', '13', 'New Case Received: Basta - Jane Doe', 'Received', '2025-05-30 15:02:33');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('66', '14', 'New Case Received: Conviction of a Crime Involving Moral Turpitude - Jack Doe', 'Received', '2025-05-30 15:03:56');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('67', '15', 'New Case Received: Waray la bag o na taxonomy - Jack Doe', 'Received', '2025-05-30 15:04:56');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('68', '16', 'New Case Received: Waray la bag o na taxonomy - Lorenz Gabriel Sabalza Jr', 'Received', '2025-05-30 15:08:54');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('69', '17', 'New Case Received: Conviction of a Crime Involving Moral Turpitude - Bob Doe', 'Received', '2025-05-30 15:14:31');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('70', '17', 'Case Update: Case is being assigned to 437-A (Jonalyn Sumayod)', 'Assigning', '2025-05-30 15:46:51');
INSERT INTO `cts_case_logs` (`id`, `case_id`, `message`, `status`, `timestamp`) VALUES ('71', '17', 'Case Update: 437-A has received the document and has been assigned to this case', 'Pending', '2025-05-30 15:46:59');

