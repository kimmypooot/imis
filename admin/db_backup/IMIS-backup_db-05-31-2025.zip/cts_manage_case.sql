-- Dumping table structure for `cts_manage_case`

CREATE TABLE `cts_manage_case` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_officer_id` int(11) DEFAULT NULL,
  `date_received_office` date DEFAULT NULL,
  `date_received_lsd` date DEFAULT NULL,
  `signatory_name` varchar(255) DEFAULT NULL,
  `document_date` date DEFAULT NULL,
  `document_type` varchar(100) DEFAULT NULL,
  `taxonomy` varchar(255) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_received` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fk_action_officer` (`action_officer_id`),
  CONSTRAINT `fk_action_officer` FOREIGN KEY (`action_officer_id`) REFERENCES `cts_manage_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_manage_case`

INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('9', '2', '2025-05-08', '2025-05-08', 'Lorenz Gabriel Sabalza', '2025-05-01', 'Letter', 'Simple Misconduct', 'Lorenz Gabriel Sabalza', 'For Releasing', '2025-05-08 01:16:35', NULL, '0');
INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('10', '1', '2025-05-30', '2025-05-30', 'Harold Ian Sablawon', '2025-05-30', 'Letter', 'Abuse of Authority', 'Harold Ian Sablawon', 'Assigning', '2025-05-30 06:13:43', NULL, '0');
INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('11', '3', '2025-05-30', '2025-05-30', 'Mark Kian Tisado', '2025-05-30', 'Decision', 'Reversion to Use of Maiden Name in the Personnel Records', 'Mark Kian Tisado', 'For Releasing', '2025-05-30 07:09:32', NULL, '0');
INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('12', NULL, '2025-05-30', '2025-05-30', 'John Doe', '2025-05-30', 'Letter', 'Basta', 'John Doe', 'Received', '2025-05-30 15:01:20', NULL, '0');
INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('13', NULL, '2025-05-30', '2025-05-30', 'Jane Doe', '2025-05-30', 'Letter', 'Basta', 'Lorenz', 'Received', '2025-05-30 15:02:32', NULL, '0');
INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('14', NULL, '2025-05-30', '2025-05-30', 'Jack Doe', '2025-05-30', 'Letter', 'Conviction of a Crime Involving Moral Turpitude', 'Mark Kian Tisado Jr', 'Received', '2025-05-30 15:03:56', NULL, '0');
INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('15', NULL, '2025-05-30', '2025-05-30', 'Jack Doe', '2025-05-30', 'Letter', 'Waray la bag o na taxonomy', 'Lorenz', 'Received', '2025-05-30 15:04:55', NULL, '0');
INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('16', NULL, '2025-05-30', '2025-05-30', 'Lorenz Gabriel Sabalza Jr', '2025-05-30', 'Letter', 'Waray la bag o na taxonomy', 'Lorenz', 'Received', '2025-05-30 15:08:54', NULL, '0');
INSERT INTO `cts_manage_case` (`id`, `action_officer_id`, `date_received_office`, `date_received_lsd`, `signatory_name`, `document_date`, `document_type`, `taxonomy`, `party`, `status`, `created_at`, `updated_at`, `is_received`) VALUES ('17', '3', '2025-05-30', '2025-05-30', 'Bob Doe', '2025-05-30', 'Letter', 'Conviction of a Crime Involving Moral Turpitude', 'Bob', 'Pending', '2025-05-30 15:14:31', NULL, '0');

