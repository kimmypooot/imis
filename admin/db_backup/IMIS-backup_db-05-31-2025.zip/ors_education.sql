-- Dumping table structure for `ors_education`

CREATE TABLE `ors_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `applicant_id` int(11) NOT NULL,
  `degree` varchar(255) NOT NULL,
  `school` varchar(255) NOT NULL,
  `year_graduated` year(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `applicant_id` (`applicant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `ors_education`

INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('1', '626', 'BSIT', 'EASTERN VISAYAS STATE UNIVERSITY', '2025');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('2', '628', 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'EASTERN VISAYAS STATE UNIVERSITY', '2025');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('3', '630', 'BSIT', 'EVSU', '2025');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('4', '632', 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'EASTERN VISAYAS STATE UNIVERSITY', '2025');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('5', '634', 'MAJOR IN BOLCA SIL', 'MINDANAO EASTERN  ', '2008');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('6', '636', 'N/A', 'EASTER VISAYAS STATE UNIVERSITY ', '2025');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('7', '638', 'BSIT', 'ADFC', '2022');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('8', '638', 'MSIT', 'ACLC', '2017');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('9', '639', 'MASTER OF ARTS IN EDUCATION', 'LEYTE NORMAL UNIVERSITY', '2019');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('10', '640', 'BSBA MAJOR IN FINANCIAL MANAGEMENT', 'ST. PETER\'S COLLEGE OF ORMOC,INC.', '2023');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('11', '641', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2017');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('12', '642', 'BACHELOR OF LAWS', 'XAVIER UNIVERSITY', '2018');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('13', '642', 'BACHELOR OF SCIENCE IN INFORMATION MANAGEMENT', 'XAVUER UNIVERSITY', '2008');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('14', '643', 'BS BUSINESS ADMINISTRATION MAJOR IN FINANCIAL MANAGEMENT', 'EASTERN SAMAR STATE UNIVERSITY-GUIUAN ', '2018');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('15', '644', 'BACHELOR OF SECONDARY EDUCATION MAJOR IN PHYSICAL EDUCATION', 'SAMAR STATE UNIVERSITY - MAIN CAMPUS (CATBALOGAN CITY, WESTERN SAMAR)', '2022');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('16', '645', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'EASTERN VISAYAS STATE UNIVERSITY', '2011');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('17', '645', 'BACHELOR OF SCIENCE IN MANAGEMENT ACCOUNTING', 'EASTERN VISAYAS STATE UNIVERSITY', '2010');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('18', '646', 'JURIS DOCTOR', 'UNIVERSITY OF CEBU SCHOOL OF LAW', '2021');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('19', '646', 'POLITICAL SCIENCE', 'UNIVERSITY OF SAN JOSE RECOLETOS', '2011');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('20', '647', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'NATIONAL COLLEGE OF BUSINESS AND ARTS - CUBAO', '2017');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('21', '648', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2001');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('22', '649', 'BS IN ACCOUNTANCY', 'EASTERN SAMAR STATE UNIVERSITY', '2014');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('23', '650', 'BACHELOR OF SCIENCE IN AGRICULTURAL AND BIOSYSTEMS ENGINEERING', 'BOHOL ISLAND STATE UNIVERSITY - BILAR CAMPUS', '2022');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('24', '651', 'MASTER IN MANAGEMENT', 'LEYTE NORMAL UNIVERSITY', '2023');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('25', '651', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2016');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('26', '652', 'JURIS DOCTOR', 'ARELLANO UNIVERSITY', '2023');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('27', '652', 'AB POLITICAL SCIENCE', 'MINDANAO STATE UNIVERSITY-ILIGAN INSTITUTE OF TECHNOLOGY', '2015');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('28', '652', '', '', '0000');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('29', '653', 'JURIS DOCTOR', 'UNIVERSITY OF SAN JOSE -RECOLETOS', '2015');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('30', '653', 'DOCTOR OF PHILOSOPHY IN PUBLIC ADMINISTRATION', 'PAMANTASANG LUNGSOD NG MARIKINA', '0000');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('31', '653', 'MASTER IN PUBLIC ADMINISTRATION', 'JOSE RIZAL UNIVERSITY', '2020');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('32', '653', 'BACHELOR OF SCIENCE IN PSYCHOLOGY', 'SOUTHWESTERN UNIVERSITY', '2010');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('33', '654', 'JURIS DOCTOR', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2019');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('34', '655', 'MASTER OF LAWS		', 'POLYTHECNIC UNIVERSITY OF THE PHILIPPINES		', '2025');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('35', '655', 'JURIS DOCTOR		', 'ST. PAUL SCHOOL OF PROFESSIONAL STUDIES		', '2020');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('36', '655', 'B.S. ACCOUNTANCY		', 'ST. PAUL SCHOOL OF PROFESSIONAL STUDIES		', '2012');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('37', '655', 'SECONDARY EDUCATION		', 'THE SISTERS OF MARY-BOYSTOWN		', '2005');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('38', '655', 'PRIMARY EDUCATION		', 'GEN. MACARTHUR CENTRAL ELEMENTARY SCHOOL		', '2002');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('39', '656', 'JURIS DOCTOR', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2019');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('40', '657', 'MASTER IN HUMAN RESOURCE MANAGEMENT', 'THE UNIVERSITY OF NEWCASTLE AUSTRALIA', '2016');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('41', '658', 'BACHELOR OF SCIENCE IN MANAGEMENT', 'UNIVERSITY OF THE PHILIPPINES TACLOBAN COLLEGE', '2023');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('42', '659', 'BS INDUSTRIAL ENGINEERING/ GRADUATE ', 'CEBU INSTITUTE OF TECHNOLOGY UNIVERSITY ', '2024');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('43', '660', 'BACHELOR OF SCIENCE IN HOME ARTS ENTREPRENEURSHIP', 'LEYTE NORMAL UNIVERSITY', '2018');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('44', '661', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'ST. PAUL SCHOOL OF PROFESSIONAL STUDIES', '2013');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('45', '662', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'SAINT PAUL SCHOOL OF BUSINESS AND LAW', '2010');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('46', '663', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'EASTERN VISAYAS STATE UNIVERSITY - TANAUAN CAMPUS', '2020');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('47', '664', 'BACHELOR OF SECONDARY EDUCATION MAJOR IN MATHEMATICS ', 'VISAYAS STATE UNIVERSITY VILLABA ', '2023');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('48', '665', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'UNIVERSIDAD DE ZAMBOANGA', '2018');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('49', '665', 'N/A', 'NOTRE DAME OF JOLO HIGHSCHOOL KASULUTAN', '2014');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('50', '665', 'N/A', 'BAKUD ELEMENTARY SCHOOL', '2010');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('51', '666', 'BACHELOR OF SCIENCE IN ACCOUNTANCY ', 'SAINT JOSEPH COLLEGE ', '2016');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('52', '667', 'BACHELOR OF SCIENCE IN COMMERCE MAJOR IN MANAGEMENT', 'SAINT JOSEPH COLLEGE, MAASIN CITY', '2007');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('53', '668', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2020');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('54', '669', 'BACHELOR OF SCIENCE IN BUSINESS ADMINISTRATION', 'EVSU', '2005');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('55', '670', 'BACHELOR OF LAWS', 'UNIVERSITY OF SAN CARLOS', '1992');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('56', '671', 'MASTER OF HUMAN RESOURCE MANAGEMENT', 'UNIVERSITY OF TECHNOLOGY SYDNEY, AUSTRALIA', '2024');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('57', '671', 'MASTER OF PUBLIC ADMINISTRATION', 'CEBU TECHNOLOGICAL UNIVERSITY', '2017');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('58', '671', 'BACHELOR OF SCIENCE IN NURSING', 'COLEGIO DE STA LOURDES OF LEYTE FOUNDATION, INC', '2013');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('59', '671', 'HIGH SCHOOL', 'LEYTE NATIONAL HIGH SCHOOL', '2009');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('60', '671', 'ELEMENTARY', 'TACLOBAN ADVENTIST ELEMENTARY SCHOOL', '2005');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('61', '672', 'DOCTOR OF PHILOSOPHY MAJOR IN EDUCATIONAL MANAGEMENT', 'ASIAN DEVELOPMENT FOUNDATION COLLEGE (ADFC)', '2019');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('62', '672', 'MASTER OF ARTS IN EDUCATION', 'ASIAN DEVELOPMENT FOUNDATION COLLEGE', '2016');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('63', '672', 'BACHELOR OF LAWS (JURIS DOCTOR)', 'DON VICENTE ORESTES ROMUALDEZ EDUCATIONAL FOUNDATION (DVOREF)', '2012');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('64', '672', 'BACHELOR OF ARTS IN MASS COMMUNICATIONS', 'LEYTE NORMAL UNIVERSITY (LNU)', '1997');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('65', '673', '', '', '0000');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('66', '674', 'MASTER IN INFORMATION TECHNOLOGY', 'ASIAN DEVELOPMENT FOUNDATION COLLEGE', '2010');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('67', '675', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2016');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('68', '676', 'MASTER OF ARTS IN INTERNATIONAL DEVELOPMENT', 'INTERNATIONAL UNIVERSITY OF JAPAN', '2005');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('69', '676', 'MASTER OF MANAGEMENT (PUBLIC MANAGEMENT) ', 'UNIVERSITY OF THE PHILIPPINES TACLOBAN COLLEGE', '2000');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('70', '676', 'BACHELOR OF ARTS IN SOCIAL SCIENCES - ECONOMICS', 'UNIVERSITY OF THE PHILIPPINES TACLOBAN COLLEGE', '1995');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('71', '677', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'EASTERN VISAYAS STATE UNIVERSITY - TACLOBAN CAMPUS', '2014');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('72', '678', 'MASTER OF MANAGEMENT-MAJOR IN PUBLIC MANAGEMENT', 'UP VISAYAS TACLOBAN COLLEGE', '2019');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('73', '678', 'BACHELOR OF LAWS', 'DVOREF', '2010');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('74', '678', 'BACHELOR IN BUSINESS ADMINISTRATION-MAJOR IN MANAGEMENT', 'UP VISAYAS TACLOBAN COLLEGE', '2003');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('75', '679', 'JURIS DOCTOR', 'LEYTE COLLEGES', '2021');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('76', '679', 'BS ACCOUNTANCY', 'EASTERN VISAYAS STATE UNIVERSITY', '2015');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('77', '680', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2018');
INSERT INTO `ors_education` (`id`, `applicant_id`, `degree`, `school`, `year_graduated`) VALUES ('78', '681', 'BACHELOR OF SCIENCE IN ACCOUNTANCY', 'SAINT PAUL SCHOOL OF PROFESSIONAL STUDIES', '2024');

