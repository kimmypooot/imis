-- Dumping table structure for `proctad_schools`

CREATE TABLE `proctad_schools` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `school` varchar(254) NOT NULL,
  `fo_id` int(12) DEFAULT NULL,
  `school_code` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_schools_fo_id_v2` (`fo_id`),
  CONSTRAINT `fk_schools_fo_id_v2` FOREIGN KEY (`fo_id`) REFERENCES `proctad_fo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_schools`

INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('1', 'Leyte National High School', '1', 'LNHS');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('2', 'Eastern Visayas State University', '1', 'EVSU');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('3', 'San Jose Central School', '1', 'SJCS');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('4', 'Sagkahan National High School', '1', 'SNHS');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('5', 'Leyte Normal University', '1', 'LNU');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('6', 'Saint Joseph College', '3', 'SJC');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('7', 'Catarman National High School', '7', 'CNHS');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('8', 'Samar National School', '5', 'SNS');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('9', 'Samar State University', '5', 'SSU');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('10', 'New Ormoc City National High School', '2', 'NOCNHS');
INSERT INTO `proctad_schools` (`id`, `school`, `fo_id`, `school_code`) VALUES ('11', 'Eastern Samar National Comprehensive High School', '6', 'ESNCHS');

