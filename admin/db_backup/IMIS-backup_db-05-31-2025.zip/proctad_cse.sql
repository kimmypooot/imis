-- Dumping table structure for `proctad_cse`

CREATE TABLE `proctad_cse` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `exam_date_id` int(12) NOT NULL,
  `exam_type_id` int(12) NOT NULL,
  `status` varchar(12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_exam_date` (`exam_date_id`),
  KEY `fk_exam_type` (`exam_type_id`),
  CONSTRAINT `fk_exam_date` FOREIGN KEY (`exam_date_id`) REFERENCES `proctad_exam_dates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_exam_type` FOREIGN KEY (`exam_type_id`) REFERENCES `proctad_exam_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_cse`

INSERT INTO `proctad_cse` (`id`, `exam_date_id`, `exam_type_id`, `status`) VALUES ('1', '1', '1', 'Active');
INSERT INTO `proctad_cse` (`id`, `exam_date_id`, `exam_type_id`, `status`) VALUES ('2', '1', '2', 'Active');
INSERT INTO `proctad_cse` (`id`, `exam_date_id`, `exam_type_id`, `status`) VALUES ('3', '2', '3', 'Active');

