-- Dumping table structure for `ighrs_db`

CREATE TABLE `ighrs_db` (
  `id` int(12) NOT NULL,
  `field_office` varchar(64) NOT NULL,
  `agency_id` int(16) NOT NULL,
  `agency` varchar(256) NOT NULL,
  `plantilla_updated` varchar(36) NOT NULL,
  `plantilla_date` varchar(36) NOT NULL,
  `plantilla_submission` varchar(36) NOT NULL,
  `casual_updated` varchar(36) NOT NULL,
  `casual_date` varchar(36) NOT NULL,
  `casual_submission` varchar(36) NOT NULL,
  `jo_updated` varchar(36) NOT NULL,
  `jo_date` varchar(36) NOT NULL,
  `jo_submission` varchar(36) NOT NULL,
  `remarks` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `ighrs_db` is empty

