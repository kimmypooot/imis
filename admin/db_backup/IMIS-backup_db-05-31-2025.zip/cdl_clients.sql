-- Dumping table structure for `cdl_clients`

CREATE TABLE `cdl_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `agency` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `division` int(11) DEFAULT NULL,
  `ao` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_client_division` (`division`),
  KEY `fk_clients_AO` (`ao`),
  CONSTRAINT `fk_client_division` FOREIGN KEY (`division`) REFERENCES `cdl_csc_divisions` (`cdl_csc_division_id`),
  CONSTRAINT `fk_clients_AO` FOREIGN KEY (`ao`) REFERENCES `cdl_csc_action_officer` (`cdl_csc_ao_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `cdl_clients` is empty

