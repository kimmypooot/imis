-- Dumping table structure for `proctad_main`

CREATE TABLE `proctad_main` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ta_id` int(12) NOT NULL,
  `testing_center` int(12) NOT NULL,
  `designation` varchar(124) NOT NULL,
  `exam_date_id` int(12) NOT NULL,
  `time_in` varchar(11) DEFAULT NULL,
  `logdate` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_briefing_ta` (`ta_id`),
  KEY `fk_briefing_center` (`testing_center`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table `proctad_main` is empty

