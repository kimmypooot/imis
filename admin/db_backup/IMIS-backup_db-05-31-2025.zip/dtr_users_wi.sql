-- Dumping table structure for `dtr_users_wi`

CREATE TABLE `dtr_users_wi` (
  `id` int(11) NOT NULL,
  `dtr_users_fname` varchar(255) NOT NULL,
  `dtr_users_lname` varchar(255) NOT NULL,
  `dtr_users_mi` varchar(255) NOT NULL,
  `dtr_users_sex` varchar(255) NOT NULL,
  `dtr_users_school` varchar(255) NOT NULL,
  `dtr_users_strand` varchar(255) NOT NULL,
  `dtr_users_date_started` date NOT NULL,
  `dtr_users_target_hours` date NOT NULL,
  `dtr_users_status_coc` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `dtr_users_wi`

INSERT INTO `dtr_users_wi` (`id`, `dtr_users_fname`, `dtr_users_lname`, `dtr_users_mi`, `dtr_users_sex`, `dtr_users_school`, `dtr_users_strand`, `dtr_users_date_started`, `dtr_users_target_hours`, `dtr_users_status_coc`, `timestamp`) VALUES ('2', 'Juan', 'Ramirre', 'J', 'Male', 'Leyte National High School', 'STEM', '2025-03-04', '2025-07-16', '', '2025-03-04 05:42:49');

