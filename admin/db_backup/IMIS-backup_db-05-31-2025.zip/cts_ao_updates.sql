-- Dumping table structure for `cts_ao_updates`

CREATE TABLE `cts_ao_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `date_received_by_ao` date DEFAULT NULL,
  `action_taken` text DEFAULT NULL,
  `case_docket_no` varchar(100) DEFAULT NULL,
  `case_type` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `cts_ao_updates_ibfk_1` (`case_id`),
  CONSTRAINT `cts_ao_updates_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cts_manage_case` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_ao_updates`

INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('9', '9', '2025-05-08', NULL, '0345123', 'Non Disciplinary', '2025-05-08 01:16:35');
INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('10', '10', NULL, NULL, NULL, NULL, '2025-05-30 06:13:43');
INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('11', '11', '2025-05-30', NULL, '2201-0786', 'Disciplinary', '2025-05-30 07:09:32');
INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('12', '12', NULL, NULL, NULL, NULL, '2025-05-30 15:01:21');
INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('13', '13', NULL, NULL, NULL, NULL, '2025-05-30 15:02:33');
INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('14', '14', NULL, NULL, NULL, NULL, '2025-05-30 15:03:56');
INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('15', '15', NULL, NULL, NULL, NULL, '2025-05-30 15:04:56');
INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('16', '16', NULL, NULL, NULL, NULL, '2025-05-30 15:08:54');
INSERT INTO `cts_ao_updates` (`id`, `case_id`, `date_received_by_ao`, `action_taken`, `case_docket_no`, `case_type`, `created_at`) VALUES ('17', '17', '2025-05-30', NULL, NULL, NULL, '2025-05-30 15:14:31');

