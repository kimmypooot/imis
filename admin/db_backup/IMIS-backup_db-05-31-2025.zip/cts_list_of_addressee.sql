-- Dumping table structure for `cts_list_of_addressee`

CREATE TABLE `cts_list_of_addressee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `rrr` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_list_of_addressee`

INSERT INTO `cts_list_of_addressee` (`id`, `name`, `address`, `rrr`) VALUES ('2', 'Lorenz Gabriel Sabalza', 'Brgy. Magay, Tanauan, Leyte', '12345');
INSERT INTO `cts_list_of_addressee` (`id`, `name`, `address`, `rrr`) VALUES ('17', 'Lorenz Gabriel Sabalza', 'Brgy. Magay, Tanauan, Leyte', '123456');
INSERT INTO `cts_list_of_addressee` (`id`, `name`, `address`, `rrr`) VALUES ('18', 'Lorenz Gabriel Sabalza Jr', 'Brgy. Magay, Tanauan, Leyte', '12345123');
INSERT INTO `cts_list_of_addressee` (`id`, `name`, `address`, `rrr`) VALUES ('19', 'Harold', 'Brgy. Magay, Tanauan, Leyte', '1234');
INSERT INTO `cts_list_of_addressee` (`id`, `name`, `address`, `rrr`) VALUES ('20', 'Harold', 'Brgy. Magay, Tanauan, Leyte', '1223345');

