-- Dumping table structure for `db_sme1st`

CREATE TABLE `db_sme1st` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certno` varchar(64) NOT NULL,
  `issuedate` varchar(24) NOT NULL,
  `effdate` varchar(24) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `mname` varchar(24) NOT NULL,
  `extname` varchar(24) NOT NULL,
  `bdate` varchar(24) NOT NULL,
  `pbirth` varchar(64) NOT NULL,
  `picture` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `db_sme1st`

INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('106', '380108140002', '29-Dec-14', '29-Dec-14', 'LAZARRA', 'SALVADOR', 'MABAO', '', '30-Mar-75', 'SAN JOSE DE BUAN, WESTERN SAMA', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('107', '380108160003', '05-Dec-16', '05-Dec-16', 'SALAZAR', 'MARK ANGELO', 'PAGASPAS', '', '21-Mar-80', 'SALCEDO, EASTERN SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('108', '380108170001', '27-Apr-17', '07-Apr-17', 'DUALLO', 'ISRAEL', 'LAUSE', '', '25-Aug-82', 'STA. RITA, SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('109', '380108170002', '30-Apr-17', '28-Apr-17', 'SIDO', 'ROBERTO', 'KUIZON', 'JR.', '31-Mar-65', 'NEGROS ORIENTAL', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('110', '380108170003', '26-Jul-17', '26-Jul-17', 'BESA', 'HEIDI', 'RIPALDA', '', '28-Nov-72', 'TACLOBAN CITY, LEYTE', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('111', '380108170004', '10-Aug-17', '09-Aug-17', 'MACION', 'EDGARDO', 'DE LEON', '', '27-Oct-58', 'MERIDA, LEYTE', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('112', '380108210001', '06-May-21', '06-May-21', 'TAMPOS', 'EDGARDO', 'VIOVICENTE', '', '06-Aug-63', 'MATAG-OB, LEYTE', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('113', '380108210002', '17-Jun-21', '17-Jun-21', 'CHUA', 'DOMINADOR', 'GAUTOS', 'JR.', '09-Nov-66', 'GUIUAN, EASTERN SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('114', '380108210003', '29-Nov-21', '29-Nov-21', 'GEPOLLO', 'PORFERIO', 'TOBES', 'JR.', '28-Jan-79', 'BOBON, NORTHERN SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('115', '380108220001', '14-Jul-22', '14-Jul-22', 'CABAL', 'JUN', 'AGUILAR', '', '03-Feb-81', 'CEBU CITY', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('116', '380108230001', '09-Feb-23', '09-Feb-23', 'JAMORAWON', 'KEVIN', 'PEDRITA', '', '14-Jan-90', 'PAGSANGHAN, SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('117', '380108230002', '03-May-23', '03-May-23', 'BALDONO', 'JENNY', 'GALO', '', '22-Jan-67', 'MAYDOLONG, EASTERN SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('118', '380108230004', '05-Jul-23', '05-Jul-23', 'GASID', 'VAL', 'PADUL', '', '23-Dec-74', 'ALLEN, NORTHERN SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('119', '380108230005', '26-Jul-23', '24-Jul-23', 'CABAHUG', 'GLENN', 'BORDEOS', '', '27-Jan-77', 'ALLEN, NORTHERN SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('120', '380108230006', '29-Aug-23', '29-Aug-23', 'LUCBAN', 'MELANY', 'SUAREZ', '', '15-Aug-75', 'PAMBUJAN, NORTHERN SAMAR', '');
INSERT INTO `db_sme1st` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('121', '380108240001', '16-Jan-24', '16-Jan-24', 'MENZON', 'WINSTON', 'BALDERIAN', '', '13-Mar-76', 'TACLOBAN CITY', '');

