-- Dumping table structure for `trip_passenger`

CREATE TABLE `trip_passenger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `trip_passenger`

INSERT INTO `trip_passenger` (`id`, `name`) VALUES ('1', 'Lorenz');
INSERT INTO `trip_passenger` (`id`, `name`) VALUES ('2', 'Renzie');
INSERT INTO `trip_passenger` (`id`, `name`) VALUES ('3', 'Leobert');
INSERT INTO `trip_passenger` (`id`, `name`) VALUES ('4', 'Jason');
INSERT INTO `trip_passenger` (`id`, `name`) VALUES ('5', 'Kian');
INSERT INTO `trip_passenger` (`id`, `name`) VALUES ('6', 'Harold');

