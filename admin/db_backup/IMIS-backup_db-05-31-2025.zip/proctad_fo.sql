-- Dumping table structure for `proctad_fo`

CREATE TABLE `proctad_fo` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `testing_center` varchar(36) NOT NULL,
  `field_office` varchar(124) NOT NULL,
  `fo_code` varchar(36) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_fo`

INSERT INTO `proctad_fo` (`id`, `testing_center`, `field_office`, `fo_code`) VALUES ('1', 'Tacloban City', 'CSC Field Office - Leyte', 'FO-Leyte');
INSERT INTO `proctad_fo` (`id`, `testing_center`, `field_office`, `fo_code`) VALUES ('2', 'Ormoc City', 'CSC Satellite Office - Western Leyte', 'SO-WL');
INSERT INTO `proctad_fo` (`id`, `testing_center`, `field_office`, `fo_code`) VALUES ('3', 'Maasin City', 'CSC Field Office - Southern Leyte', 'FO-SL');
INSERT INTO `proctad_fo` (`id`, `testing_center`, `field_office`, `fo_code`) VALUES ('4', 'Biliran', 'CSC Field Office - Biliran', 'FO-Biliran');
INSERT INTO `proctad_fo` (`id`, `testing_center`, `field_office`, `fo_code`) VALUES ('5', 'Catbalogan City', 'CSC Field Office - Samar', 'FO-Samar');
INSERT INTO `proctad_fo` (`id`, `testing_center`, `field_office`, `fo_code`) VALUES ('6', 'Borongan City', 'CSC Field Office - Eastern Samar', 'FO-ES');
INSERT INTO `proctad_fo` (`id`, `testing_center`, `field_office`, `fo_code`) VALUES ('7', 'Catarman, N. Samar', 'CSC Field Office - Northern Samar', 'FO-NS');
INSERT INTO `proctad_fo` (`id`, `testing_center`, `field_office`, `fo_code`) VALUES ('8', 'CSC Regional Office VIII', 'CSC RO VIII Employee', 'CSC RO VIII');

