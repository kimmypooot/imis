-- Dumping table structure for `system_access`

CREATE TABLE `system_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(12) NOT NULL,
  `otrs` varchar(10) NOT NULL,
  `eris` varchar(10) NOT NULL,
  `ors` varchar(10) NOT NULL,
  `cdl` varchar(10) NOT NULL,
  `iis` varchar(10) NOT NULL,
  `rfcs` varchar(10) NOT NULL,
  `dvs` varchar(10) NOT NULL,
  `cts` varchar(10) NOT NULL,
  `lms` varchar(10) NOT NULL,
  `psed` varchar(12) NOT NULL,
  `rooms` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `system_access`

INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('1', '1', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'User', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('2', '2', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'User', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('3', '3', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'User', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('4', '6', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('5', '7', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('6', '8', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'Superadmin', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('7', '9', 'Admin', 'Admin', 'Admin', 'Admin', 'Admin', 'User', 'Admin', 'None', 'Admin', 'Admin', 'Admin');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('8', '10', 'None', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('9', '11', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('10', '15', 'None', 'None', 'None', 'None', 'None', 'User', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('11', '5', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('12', '14', 'Admin', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('13', '12', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('14', '13', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('15', '16', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('16', '4', 'None', 'None', 'None', 'None', 'None', 'User', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('17', '17', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('18', '18', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('19', '19', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('20', '20', 'None', 'None', 'None', 'None', 'None', 'User', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('21', '21', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('22', '22', 'None', 'None', 'None', 'None', 'None', 'User', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('23', '23', 'None', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('24', '26', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'User', 'Admin', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('25', '25', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('26', '27', 'None', 'None', 'None', 'None', 'None', 'User', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('27', '28', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('28', '24', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('29', '29', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('30', '31', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('31', '30', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'User', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('32', '32', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('33', '35', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('34', '34', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('35', '36', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('36', '33', 'None', 'None', 'None', 'None', 'None', 'Admin', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('37', '37', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'User', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('38', '38', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('39', '39', 'None', 'None', 'None', 'None', 'None', 'User', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('40', '40', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('41', '43', 'None', 'None', 'None', 'None', 'None', 'User', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('42', '41', 'None', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('43', '42', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('44', '44', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('45', '45', 'None', 'Admin', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('46', '47', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('47', '46', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'Admin', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('48', '48', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('49', '49', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('50', '50', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('51', '51', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('52', '52', 'None', 'User', 'None', 'Admin', 'Admin', 'Admin', 'None', 'Admin', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('53', '53', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');
INSERT INTO `system_access` (`id`, `user`, `otrs`, `eris`, `ors`, `cdl`, `iis`, `rfcs`, `dvs`, `cts`, `lms`, `psed`, `rooms`) VALUES ('54', '54', 'User', 'User', 'None', 'None', 'None', 'None', 'None', 'None', 'None', '', '0');

