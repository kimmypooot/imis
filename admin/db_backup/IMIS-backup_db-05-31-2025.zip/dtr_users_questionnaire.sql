-- Dumping table structure for `dtr_users_questionnaire`

CREATE TABLE `dtr_users_questionnaire` (
  `id` int(11) NOT NULL,
  `dtr_users` int(11) NOT NULL,
  `q1` text NOT NULL,
  `q2` text NOT NULL,
  `q3` text NOT NULL,
  `q4` int(11) NOT NULL,
  `q5` int(11) NOT NULL,
  `q6` int(11) NOT NULL,
  `q7` int(11) NOT NULL,
  `q8` int(11) NOT NULL,
  `q9` int(11) NOT NULL,
  `q10` int(11) NOT NULL,
  `q11` int(11) NOT NULL,
  `q12` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_intern_questionnaire` (`dtr_users`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `dtr_users_questionnaire`

INSERT INTO `dtr_users_questionnaire` (`id`, `dtr_users`, `q1`, `q2`, `q3`, `q4`, `q5`, `q6`, `q7`, `q8`, `q9`, `q10`, `q11`, `q12`, `timestamp`) VALUES ('2', '1', 'test', 'test', 'test', '1', '1', '2', '2', '1', '0', '0', '0', 'test', '2025-03-26 03:35:10');

