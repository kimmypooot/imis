-- Dumping table structure for `cts_post_decision_actions`

CREATE TABLE `cts_post_decision_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `dec_reso_no` varchar(255) DEFAULT NULL,
  `dec_reso_date` date DEFAULT NULL,
  `gist_of_action` int(11) DEFAULT NULL,
  `penalty` int(11) DEFAULT NULL,
  `remarks_to_gist` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_received` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cts_post_decision_actions_ibfk_1` (`case_id`),
  CONSTRAINT `cts_post_decision_actions_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cts_manage_case` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_post_decision_actions`

INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('9', '9', '12345', '2025-05-08', '1', '1', 'Nothing', '2025-05-08 01:16:35', '0');
INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('10', '10', NULL, NULL, NULL, NULL, NULL, '2025-05-30 06:13:43', '0');
INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('11', '11', '123456', '2025-05-30', '1', '1', 'Nothing', '2025-05-30 07:09:32', '0');
INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('12', '12', NULL, NULL, NULL, NULL, NULL, '2025-05-30 15:01:21', '0');
INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('13', '13', NULL, NULL, NULL, NULL, NULL, '2025-05-30 15:02:33', '0');
INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('14', '14', NULL, NULL, NULL, NULL, NULL, '2025-05-30 15:03:56', '0');
INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('15', '15', NULL, NULL, NULL, NULL, NULL, '2025-05-30 15:04:56', '0');
INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('16', '16', NULL, NULL, NULL, NULL, NULL, '2025-05-30 15:08:54', '0');
INSERT INTO `cts_post_decision_actions` (`id`, `case_id`, `dec_reso_no`, `dec_reso_date`, `gist_of_action`, `penalty`, `remarks_to_gist`, `created_at`, `is_received`) VALUES ('17', '17', NULL, NULL, NULL, NULL, NULL, '2025-05-30 15:14:31', '0');

