-- Dumping table structure for `users_seis`

CREATE TABLE `users_seis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `division` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `users_seis`

INSERT INTO `users_seis` (`id`, `username`, `password`, `name`, `role`, `type`, `division`, `timestamp`) VALUES ('1', 'superadmin', '$2y$10$UPYc7udgiaLo73ype6CIheP8O84BUxiLvh59SerTvdz04tCwSEEpa', 'Human Resource Division', 'hrd', 'admin', '1', '2025-02-19 08:32:56');

