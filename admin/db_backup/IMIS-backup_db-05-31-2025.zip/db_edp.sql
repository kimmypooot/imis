-- Dumping table structure for `db_edp`

CREATE TABLE `db_edp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certno` varchar(64) NOT NULL,
  `issuedate` varchar(24) NOT NULL,
  `effdate` varchar(24) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `mname` varchar(24) NOT NULL,
  `extname` varchar(24) NOT NULL,
  `bdate` varchar(24) NOT NULL,
  `pbirth` varchar(64) NOT NULL,
  `picture` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `db_edp`

INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('151', '320108160001', '23-Nov-16', '23-Nov-16', 'CORDERO', 'KENVER', 'ROSALES', '', '06-Jul-94', 'TACLOBAN CITY', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('152', '320108160002', '07-Dec-16', '07-Dec-16', 'AMASA', 'DONATO VALENTI LEANDRO', 'BAUTISTA', '', '31-Mar-95', 'BORONGAN, EASTERN SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('153', '320108170001', '26-Jul-17', '26-Jul-17', 'MAICO', 'AQUILINO', 'DE LA TORRE', 'II', '19-Jul-89', 'ABUYOG, LEYTE', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('154', '320108170002', '07-Nov-17', '07-Nov-17', 'AGRAMON', 'MARICEL', 'MARTINEZ', '', '17-Nov-84', 'BARUGO, LEYTE', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('155', '320108170003', '07-Nov-17', '07-Nov-17', 'CANUDAY', 'JACKERON', 'TING', '', '31-Jul-82', 'CALOOCAN CITY', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('156', '320108170004', '14-Dec-17', '12-Dec-17', 'TOMAS', 'ALEXIS', 'BALBUENA', '', '27-Jan-83', 'CATBALOGAN, SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('157', '320108190001', '23-May-19', '23-May-19', 'CHAVEZ', 'STEPHEN JAMES', 'MARTINEZ', '', '11-Nov-90', 'BAYBAY, LEYTE', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('158', '320108190002', '28-May-19', '28-May-19', 'VILLAS', 'NORMAN', 'ORTEGA', '', '11-May-90', 'BAYBAY, LEYTE', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('159', '320108220001', '05-May-22', '05-May-22', 'ZOSA', 'NEVHAN CLIFF', 'PALIGUTAN', '', '29-May-82', 'CATBALOGAN, SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('160', '320108220002', '03-Jun-22', '03-Jun-22', 'FLORA', 'ROBERT', 'RIVERA', '', '28-Jul-84', 'CATBALOGAN, SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('161', '320108220003', '15-Jun-22', '15-Jun-22', 'CINCO', 'JEFFREY', 'COSTINIANO', '', '09-Jan-93', 'TANAUAN, LEYTE', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('162', '320108230001', '13-Feb-23', '13-Feb-23', 'GELI', 'ROMUALDO', 'LEGUARDA', 'JR.', '11-Dec-93', 'CAN-AVID, EASTERN SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('163', '320108230002', '20-Feb-23', '20-Feb-23', 'GOHIL', 'GERRY', 'SOLIS', 'JR.', '07-Apr-90', 'ABUYOG, LEYTE', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('164', '320108230003', '07-Mar-23', '07-Mar-23', 'SANTOS', 'EMMANUEL', 'BARBOSA', 'III', '31-Aug-97', 'TACLOBAN CITY', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('165', '320108230004', '27-Apr-23', '27-Apr-23', 'ABAYON', 'MARK JIL', 'CATAMORA', '', '11-Sep-87', 'SAN ISIDRO, NORTHERN SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('166', '320108230005', '04-May-23', '04-May-23', 'CORPIN', 'ACE DENVER', 'PEDRIGAL', '', '13-Jul-90', 'TACLOBAN CITY', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('167', '320108230006', '09-Aug-23', '09-Aug-23', 'PERANTE', 'FERDIWIL JUDE', 'ABARSOSA', '', '02-Jul-90', 'MANILA', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('168', '320108240001', '18-Jan-24', '18-Jan-24', 'BALO', 'STEPHEN JANSEEN', 'DELA PEÑA', '', '26-Nov-93', 'MANILA', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('169', '320108240002', '26-Jan-24', '26-Jan-24', 'LUCERO', 'RONALD', 'ORONOS', '', '01-May-93', 'MANILA', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('170', '320108240003', '27-Feb-24', '27-Feb-24', 'ECHALUCE', 'TOMAS PAOLO', 'ALBURAN', '', '12-Nov-97', 'MONDRAGON, N. SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('171', '320108240004', '19-Mar-24', '19-Mar-24', 'JAGUINES', 'OLIVER', 'BARRINA', '', '20-Mar-98', 'ALMERIA, BILIRAN', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('172', '320108240005', '03-Apr-24', '03-Apr-24', 'GARCIA', 'NOEL', 'ALMADEN', '', '05-Mar-97', 'TANAUAN, LEYTE', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('173', '320108240006', '29-Apr-24', '29-Apr-24', 'BABON', 'BRYAN', 'PITAO', '', '04-Nov-93', 'CATBALOGAN, SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('174', '320108240007', '15-Jul-24', '15-Jul-24', 'BAGARES', 'DARRYL JOSEPH', 'AGRAVA', '', '07-Mar-95', 'TACLOBAN CITY', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('175', '320108240008', '30-Aug-24', '30-Aug-24', 'MELQUIADES', 'DOROTHY', 'DAJOYA', '', '28-Jul-99', 'TACLOBAN CITY', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('176', '320108240009', '16-Oct-24', '16-Oct-24', 'ORBONG', 'NOEL', 'SABIAN', 'JR.', '16-Apr-94', 'TALALORA, SAMAR', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('177', '320108240010', '26-Dec-24', '26-Dec-24', 'CAGARA', 'VINCENT FELIX', 'SABALZA', '', '22-Oct-01', 'TACLOBAN CITY', '');
INSERT INTO `db_edp` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('178', '320108250001', '06-Jan-25', '06-Jan-25', 'SIMBORIO', 'MARK', 'SASING', '', '10-Jun-86', 'ABUYOG, LEYTE', '');

