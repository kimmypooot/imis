-- Dumping table structure for `cdl_csc_action_officer`

CREATE TABLE `cdl_csc_action_officer` (
  `cdl_csc_ao_id` int(11) NOT NULL AUTO_INCREMENT,
  `cdl_csc_ao_name` varchar(255) NOT NULL,
  `cdl_csc_ao_division` int(11) NOT NULL,
  PRIMARY KEY (`cdl_csc_ao_id`),
  KEY `fk_ao_division` (`cdl_csc_ao_division`),
  CONSTRAINT `fk_ao_division` FOREIGN KEY (`cdl_csc_ao_division`) REFERENCES `cdl_csc_divisions` (`cdl_csc_division_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `cdl_csc_action_officer`

INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('2', 'Atty. Marilyn E. Taldo', '16');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('3', 'Atty. Flordeliza C. Algas', '16');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('4', 'Ma. Desiree T. Duzon', '16');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('5', 'Geomelyn Q. Caparroso', '16');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('6', 'Cristy Joy Q. Macasil', '2');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('7', 'Georgina O. Delmo', '2');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('8', 'Ma. Victoria P. Arevalo', '2');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('9', 'Banello P. Gabon, Ph.D', '4');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('10', 'Rowell P. Amor', '4');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('11', 'Atty. Norberto J. Lesiguez', '4');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('12', 'Julie Ann N. Monterde', '5');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('13', 'Catherine C. Rona', '5');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('14', 'Maribeth F. Andriano', '5');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('15', 'Romel A. Lingo', '5');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('16', 'Eleonor B. Garcia', '5');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('17', 'Cristano H. Cortes', '5');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('18', 'Richmond A. Sanglay', '11');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('19', 'Cerise D. Verzosa', '11');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('20', 'Atty. Benjie M. Gelizon', '10');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('21', 'Michael M. Dela Cruz', '10');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('22', 'Ryan Jose M. Estoque', '3');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('23', 'Maico V. Soledad', '3');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('24', 'Elizar T. Casinillo', '3');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('25', 'Sharmyn A. Salvo', '3');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('26', 'Raymond S. Basiano', '3');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('27', 'Atty. Gervien T. Berecio', '3');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('28', 'Bonita T. Arcelo', '15');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('29', 'Michael M. Dela Cruz', '15');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('30', 'Donabel Gay F. Fuentes', '1');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('31', 'Christian B. Soledad', '1');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('32', 'Paulita L. Filamor', '1');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('33', 'Kim Benedick M. Banoyo', '1');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('34', 'Jay M. Merelos', '1');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('37', 'Atty. Jean T. Balledo', '8');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('38', 'Jonalyn D. Sumayod', '8');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('39', 'Atty. Antonia B. Quijano', '8');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('40', 'Atty. Otelia Fe C. Aguillon', '8');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('41', 'Atty. Ma. Charmaine C. Apelado-Bula', '8');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('43', 'Juval Niel A. Morden', '6');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('44', 'Ma. Natividad L. Costibolo', '7');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('45', 'Marjorie Anne F. Cadiz', '7');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('46', 'Sheryl M. Cumpio', '7');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('47', 'Rogelio B. Ramos', '7');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('48', 'Charl G. Pabillon', '14');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('49', 'Pharida Q. Aurelia', '9');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('50', 'Don Mark Phillipe D. De Los Reyes', '9');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('51', 'Vicente C. Tolosa', '9');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('52', 'Ma. Lourdes H. Sabalza', '9');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('53', 'Jason Thaddeus A. Tan', '13');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('54', 'Mark Jacob L. De Paz', '13');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('55', 'Rey Albert B. Uy', '13');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('56', 'Lucille K. Lepasana', '12');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('57', 'Rey Albert B. Uy', '12');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('60', 'Hello World', '1');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('61', 'Lorenz Gabriel Sabalza', '1');
INSERT INTO `cdl_csc_action_officer` (`cdl_csc_ao_id`, `cdl_csc_ao_name`, `cdl_csc_ao_division`) VALUES ('62', 'Juan De La Cruz', '16');

