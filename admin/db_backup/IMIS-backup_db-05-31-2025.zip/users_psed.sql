-- Dumping table structure for `users_psed`

CREATE TABLE `users_psed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(24) NOT NULL,
  `password` varchar(128) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `type` varchar(24) NOT NULL,
  `role` varchar(18) NOT NULL,
  `remember_me_token` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `users_psed`

INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('1', 'cscro8.psed', '$2y$10$OMhVWwaCBKyqcqtImMyr5.FyEkQXgbRnnMnjlg1YZFgeb52xTmw6O', 'CSC RO VIII - Policies and Systems Evaluation Division', 'ro08.psed@csc.gov.ph', 'psed', 'admin', 'f88b67eb86c3c0fb461c0a9b22123972991e439c972b99b2d85d1d28a97bf6ad');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('2', 'cscfo.leytei', '$2y$10$5C7lYzMjWiQ5V7jVRzT3IOQgmpxd8is2cP7hFL78J9/SpHPlYKoCG', 'CSC Field Office - Leyte I', 'ro08.fo_leytei@csc.gov.ph', 'lfoi', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('3', 'cscfo.leyteii', '$2y$10$QHy92pY11Yap5dAFdP22/eT9wSL44wwekuSOUir2uP7GQzgwt87C.', 'CSC Field Office - Leyte II', 'ro08.fo_leyteii@csc.gov.ph', 'lfoii', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('4', 'cscfo.biliran', '$2y$10$ga9mruGCtoeHw8/KguUA6OdebDzk8vAq28SZ9BeLjaVOqjf22gQQC', 'CSC Field Office - Biliran', 'kmbanoyo@csc.gov.ph', 'fob', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('5', 'cscso.westernleyte', '$2y$10$L2HSkqCC/M2EsqCY8uiQ0ennZsi9GIQAA60j0YXHD2hSxpvJY8VIu', 'CSC Satellite Office - Western Leyte', 'ro08.so_westernleyte@csc.gov.ph', 'wlso', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('6', 'cscfo.southernleyte', '$2y$10$fTnb9KDNQcVwXHbFbggX4uhQCPD90ImkI4dS1A36CHxEQDnIdmsx.', 'CSC Field Office - Southern Leyte', 'ro08.fo_southernleyte@csc.gov.ph', 'slfo', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('7', 'cscfo.samar', '$2y$10$1V8O7WJBZXOMfIZ7BpAsXu1Yve2bz9wihf6XTVmp1W4s4PckC5taG', 'CSC Field Office - Samar', 'ro08.fo_westernsamar@csc.gov.ph', 'sfo', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('8', 'cscfo.easternsamar', '$2y$10$Ww9JCiMG/TXl61BpaCgFcOZSZeJ8IuDm.5Q6U9QyjxACchH/l7YJa', 'CSC Field Office - Eastern Samar', 'ro08.fo_easternsamar@csc.gov.ph', 'esfo', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('9', 'cscfo.northernsamar', '$2y$10$C/Owvj/EU.vUljicZ9TR2upTz88kNRikCfY4b3K7UtoJfkyS5yRsC', 'CSC Field Office - Northern Samar', 'ro08.fo_northernsamar@csc.gov.ph', 'nsfo', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('10', 'cscro8.ord', '$2y$10$OMhVWwaCBKyqcqtImMyr5.FyEkQXgbRnnMnjlg1YZFgeb52xTmw6O', 'CSC RO VIII - Office of the Regional Director', 'ro08@csc.gov.ph', 'ord', 'admin', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('11', 'cscro8.oard', '$2y$10$OMhVWwaCBKyqcqtImMyr5.FyEkQXgbRnnMnjlg1YZFgeb52xTmw6O', 'CSC RO VIII - Office of the Assistant Regional Director', 'ro08.oard@csc.gov.ph', 'oard', 'admin', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('12', 'cscro8.lsd', '$2y$10$OMhVWwaCBKyqcqtImMyr5.FyEkQXgbRnnMnjlg1YZFgeb52xTmw6O', 'CSC RO VIII - Legal Services Division', 'ro08.lsd@csc.gov.ph', 'lsd', 'user', '');
INSERT INTO `users_psed` (`id`, `username`, `password`, `name`, `email`, `type`, `role`, `remember_me_token`) VALUES ('13', 'cscro8.hrd', '$2y$10$OMhVWwaCBKyqcqtImMyr5.FyEkQXgbRnnMnjlg1YZFgeb52xTmw6O', 'CSC RO VIII - Human Resource Division', 'ro08.hrd@csc.gov.ph', 'hrd', 'admin', '');

