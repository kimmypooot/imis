-- Dumping table structure for `psed_spear_rr`

CREATE TABLE `psed_spear_rr` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `psed_spear_year` varchar(12) NOT NULL,
  `psed_spear_details` varchar(124) NOT NULL,
  `psed_spear_rr` varchar(512) NOT NULL,
  `psed_spear_acc` varchar(1024) NOT NULL,
  `psed_spear_bronze` varchar(1024) NOT NULL,
  `psed_spear_silver` varchar(1024) NOT NULL,
  `psed_spear_gold` varchar(1024) NOT NULL,
  `psed_spear_total` varchar(12) NOT NULL,
  `psed_spear_budget` varchar(16) NOT NULL,
  `psed_spear_expenses` varchar(16) NOT NULL,
  `psed_spear_file` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `psed_spear_rr` is empty

