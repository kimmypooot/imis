-- Dumping table structure for `sets_office`

CREATE TABLE `sets_office` (
  `id` int(11) NOT NULL,
  `division_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `sets_office`

INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('1', 'Examination Services Division');
INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('2', 'CSC Field Office - Leyte I');
INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('3', 'CSC Field Office - Leyte II');
INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('4', 'CSC Field Office - Eastern Samar');
INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('5', 'CSC Field Office - Samar');
INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('6', 'CSC Field Office - Biliran');
INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('7', 'CSC Field Office - Southern Leyte');
INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('8', 'CSC Satellite Office - Western Leyte');
INSERT INTO `sets_office` (`id`, `division_name`) VALUES ('9', 'CSC Field Office - Northern Samar');

