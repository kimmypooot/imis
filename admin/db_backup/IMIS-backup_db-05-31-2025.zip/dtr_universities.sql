-- Dumping table structure for `dtr_universities`

CREATE TABLE `dtr_universities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school` varchar(255) NOT NULL,
  `campus` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `dtr_universities`

INSERT INTO `dtr_universities` (`id`, `school`, `campus`, `address`, `timestamp`) VALUES ('1', 'Eastern Visayas State University', 'Main Campus', 'Salazar St, Downtown, Tacloban, Leyte', '2025-03-04 05:43:51');
INSERT INTO `dtr_universities` (`id`, `school`, `campus`, `address`, `timestamp`) VALUES ('6', 'Burauen Community College', 'Burauen Campus', 'Burauen, Leyte', '2025-03-21 06:36:29');
INSERT INTO `dtr_universities` (`id`, `school`, `campus`, `address`, `timestamp`) VALUES ('7', 'University of the Philippines', 'Tacloban College', '62W5+X55, Magsaysay Blvd, Downtown, Tacloban City, Leyte', '2025-05-15 05:03:21');

