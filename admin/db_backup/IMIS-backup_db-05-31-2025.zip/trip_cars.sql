-- Dumping table structure for `trip_cars`

CREATE TABLE `trip_cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `plate_number` varchar(255) NOT NULL,
  `cylinder` int(11) NOT NULL,
  `ntpkm` int(11) NOT NULL,
  `current_odo` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `purchase_date` date DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `trip_cars`

INSERT INTO `trip_cars` (`id`, `name`, `plate_number`, `cylinder`, `ntpkm`, `current_odo`, `img`, `status`, `purchase_date`, `timestamp`) VALUES ('1', 'Toyota Vios', '23LK', '4', '9', '330', '1742614425_vios.jpg', 'Completed', '2025-03-19', '2025-03-22 03:33:45');
INSERT INTO `trip_cars` (`id`, `name`, `plate_number`, `cylinder`, `ntpkm`, `current_odo`, `img`, `status`, `purchase_date`, `timestamp`) VALUES ('2', 'Toyota HiLux', 'JK267', '4', '9', '220', '1742614457_hilux.jpg', 'Fixed', '2025-03-01', '2025-03-22 03:34:17');
INSERT INTO `trip_cars` (`id`, `name`, `plate_number`, `cylinder`, `ntpkm`, `current_odo`, `img`, `status`, `purchase_date`, `timestamp`) VALUES ('3', 'HiAce Grandia', '55AD', '4', '9', '12', '1742614497_toyota-hiace-gl-grandia-tourer-605d8f8186971.jpg', '', '2025-03-26', '2025-03-22 03:34:57');
INSERT INTO `trip_cars` (`id`, `name`, `plate_number`, `cylinder`, `ntpkm`, `current_odo`, `img`, `status`, `purchase_date`, `timestamp`) VALUES ('4', 'Toyota Supra', 'JHK1', '4', '9', '120', '1742614626_2020-toyota-supra-gray-1552941613.jpg', 'Completed', '2025-03-26', '2025-03-22 03:37:06');
INSERT INTO `trip_cars` (`id`, `name`, `plate_number`, `cylinder`, `ntpkm`, `current_odo`, `img`, `status`, `purchase_date`, `timestamp`) VALUES ('6', 'Tamaraw FXs', 'HAG 1988', '4', '9', '12', '1742803231_Screenshot (5).png', '', '2025-03-26', '2025-03-24 08:00:31');
INSERT INTO `trip_cars` (`id`, `name`, `plate_number`, `cylinder`, `ntpkm`, `current_odo`, `img`, `status`, `purchase_date`, `timestamp`) VALUES ('11', 'Rolls Royce Phantom', 'HAC 1901', '12', '4', '1302', 'RollsRoycePhantomHAC1901.jpg', '', '2025-05-15', '2025-05-15 01:14:08');

