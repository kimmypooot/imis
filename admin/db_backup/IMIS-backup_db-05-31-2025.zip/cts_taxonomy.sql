-- Dumping table structure for `cts_taxonomy`

CREATE TABLE `cts_taxonomy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(124) NOT NULL,
  `name` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_taxonomy`

INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('1', 'Disciplinary Cases', 'Abuse of Authority');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('2', 'Disciplinary Cases', 'Borrowing Money by Superior Officers from Subordinates');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('3', 'Disciplinary Cases', 'Conduct Prejudicial to the Best Interest of the Service');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('4', 'Disciplinary Cases', 'Contracting Loans of Money or other Property from Persons with whom the Office of the Employee has Business Relations');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('5', 'Disciplinary Cases', 'Conviction of a Crime Involving Moral Turpitude');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('6', 'Disciplinary Cases', 'Directly or Indirectly having Financial and Material Interest in any Transaction requiring the Approval of his/her Office.  Financial and Material Interest is defined as pecuniary or propriety interest by which a person will gain or lose something');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('7', 'Disciplinary Cases', 'Disclosing or Misusing Confidential or Classified Information Officially known to him/her by reason of his/her Office and not made available to the Public, to futher his/her private interests or give undue advantage to anyone, or to prejudice the public interest;');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('8', 'Disciplinary Cases', 'Discourtesy in the Course of Official Duties');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('9', 'Disciplinary Cases', 'Disgraceful and Immoral Conduct');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('10', 'Disciplinary Cases', 'Disgraceful, Immoral or Dishonest Conduct Prior to Entering the Service');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('11', 'Disciplinary Cases', 'Disloyalty to the Republic of the Philippines and to the Filipino People');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('12', 'Disciplinary Cases', 'Engaging Directly or Indirectly in Partisan Political Activities by One Holding Non-Political Office');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('13', 'Disciplinary Cases', 'Engaging in Private Practice of his/her Profession unless authorized by the Constitution, law or regulation, provided that such practice will not conflict with his/her official functions');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('14', 'Disciplinary Cases', 'Failure to Act Promptly on Letters and Request within Fifteen (15) working days from receipt, except otherwise provided in the rules implementing the Code of Conduct and Ethical Standards for Public Officials and Employees');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('15', 'Disciplinary Cases', 'Failure to Attend to Anyone who wants to Avail Himself/Herself of the Services of the Office, or Act Promptly and Expeditiously on Public Transactions');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('16', 'Disciplinary Cases', 'Failure to File Sworn Statements of Assets, Liabilities and Net Worth, and Disclosure of Business Interest and Financial Connection including those of Their spouses and unmarried children under eighteen (18) years of age living in their Households');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('17', 'Disciplinary Cases', 'Failure to Process Documents and Complete Action on Documents and Papers within a Reasonable Time from Preparation thereof, except otherwise provided in the rules implementing the Code of Conduct and Ethical Standards for Public Officials and Employees');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('18', 'Disciplinary Cases', 'Failure to Resign from his/her position in the Private Business Enterprise within Thirday (30) days from Assumption of Public Office when conflict of interest arises, and/or failure to divest himself/herselft of his/her shareholdings or interest in private business enterprise within sixty (60) days from assumption of public office when conflict of interest arises; Provided, however, that for those who are already in the service and conflict of interest arises, the official or employee must either resign or divest himself/herself of said interest within the periods hereinabove provided, reckoned from the date when the conflict of interest had arisen');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('19', 'Disciplinary Cases', 'Falsification of Official Document/s');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('20', 'Disciplinary Cases', 'Frequest Unauthorized Absences');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('21', 'Disciplinary Cases', 'Frequest Unauthorized Tardiness in Reporting for Duty (Habitual Tardiness)');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('22', 'Disciplinary Cases', 'Loafing from Duty during Regular Office Hours');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('23', 'Disciplinary Cases', 'Gambling Prohibited by Law');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('24', 'Disciplinary Cases', 'Grave Misconduct');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('25', 'Disciplinary Cases', 'Gross Insubordination');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('26', 'Disciplinary Cases', 'Gross Neglect of Duty');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('27', 'Disciplinary Cases', 'Habitual Drunkenness');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('28', 'Disciplinary Cases', 'Improper or Unauthorized Solicitation of Contributions from Subordinate Employees and by Teachers or School Officials from School Children');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('29', 'Disciplinary Cases', 'Indirect Contempt');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('30', 'Disciplinary Cases', 'Inefficiency and Incompetence in the Performance of Official Duties');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('31', 'Disciplinary Cases', 'Insubordination');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('32', 'Disciplinary Cases', 'Less Serious Dishonesty');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('33', 'Disciplinary Cases', 'Lobbying for Personal Interest or Gain in Legislative Halls and Offices without Authority');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('34', 'Disciplinary Cases', 'Nepotism');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('35', 'Disciplinary Cases', 'Obtaining or Using any Statement filed under the Code of Conduct and Ethical Standards for Public Officials and Employees for any Purpose Contrary to Morals or Public Policy or commercial purpose other than by news and communications media for dissemination to the general public');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('36', 'Disciplinary Cases', 'Oppression');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('37', 'Disciplinary Cases', 'Owning, Controlling, Managing or Accepting Employment as Officer, Employee, Consultant, Counsel, Broker, Agent, Trustee, or Nominee in any Private Enterprise regulated, supervised or licensed by his/her Office, unless expressly allowed by law');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('38', 'Disciplinary Cases', 'Physical or Mental Incapacity or Disability due to immoral or vicious habits');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('39', 'Disciplinary Cases', 'Promoting the Sale of Tickets in Behalf of Private Enterprises that are not intended for charitable or public welfare purposes and even in the latter cases, if there is no prior authority');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('40', 'Disciplinary Cases', 'Pursuit of Private Business, Vocation or Profession without the Permission by Civil Service Rules and Regulations');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('41', 'Disciplinary Cases', 'Receiving for Personal Use of a Fee, Gift or other Valuable thing in the Course of Official Duties or in connection therewith when such fee, gift or other valuable thing is given by any person in the hope or expectation of receiving a favor or better treatment than that accorded to other persons, or committing acts punishable under the anti-graft laws');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('42', 'Disciplinary Cases', 'Recommending any person to any position in a private enterprise which has a regular or pending official transaction with his/her office, unless such recommendation or referral is mandated by (1) law, or (2) international agreements, commitment and obligation, or as part of the function of his/her office');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('43', 'Disciplinary Cases', 'Refusal to Perform Official Duty');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('44', 'Disciplinary Cases', 'Refusal to Render Overtime Service');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('45', 'Disciplinary Cases', 'Serious Dishonesty');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('46', 'Disciplinary Cases', 'Sexual Harassment');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('47', 'Disciplinary Cases', 'Simple Discourtesy in the Couse of Official Duties');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('48', 'Disciplinary Cases', 'Simple Misconduct');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('49', 'Disciplinary Cases', 'Simple Neglect of Duty');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('50', 'Disciplinary Cases', 'Soliciting or Accepting Directly or Indirectly, any Gift, Gratuity, Favor, Entertainment, Loan or Anything of Monetary Value which in the Course of his/her Official Duties or in connection with any operation being regulated by, or any transaction which may be affected by the functions of his/her office.  The propriety or impropriety of the foregoing shall be determined by its value, kinship, or relationship between giver and receiver and the motivation.  A thing of monetary value is one which is evidently or manifestly excessive by its very nature');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('51', 'Disciplinary Cases', 'Transfer of Venue');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('52', 'Disciplinary Cases', 'Unfair Discrimination in Rendering Public Service due to Party Affiliation or Preference');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('53', 'Disciplinary Cases', 'Violation of Existing Civil Service Law and Rules of Serious Nature');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('54', 'Disciplinary Cases', 'Violation of Reasonable Office Rules and Regulations');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('55', 'Disciplinary Cases', 'Violation of Republic Act No. 3019');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('56', 'Disciplinary Cases', 'Violation of Republic Act No. 6713');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('57', 'Disciplinary Cases', 'Violation of Republic Act No. 9485');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('58', 'Disciplinary Cases', 'Willful Failure to Pay Just Debts');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('59', 'Disciplinary Cases', 'Willful Failure to Pay Taxes due to the Government');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('60', 'Non-Disciplinary Cases', 'Accreditation of Service');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('61', 'Non-Disciplinary Cases', 'Backwages/Back Salaries');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('62', 'Non-Disciplinary Cases', 'Claims for Benefits (Leave & Other Benefits)');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('63', 'Non-Disciplinary Cases', 'Correction of Personal Information');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('64', 'Non-Disciplinary Cases', 'Demotion');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('65', 'Non-Disciplinary Cases', 'Detail');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('66', 'Non-Disciplinary Cases', 'Disapproval of Appointment/s');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('67', 'Non-Disciplinary Cases', 'Dropping from the Rolls; Absence Without Approved Leave (AWOL)');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('68', 'Non-Disciplinary Cases', 'Dropping from the Rolls; Physically Unfit');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('69', 'Non-Disciplinary Cases', 'Dropping from the Rolls; Unsatisfactory or Poor Performance');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('70', 'Non-Disciplinary Cases', 'Extension of Service');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('71', 'Non-Disciplinary Cases', 'Invalidation of Appointment/s');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('72', 'Non-Disciplinary Cases', 'Promotion');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('73', 'Non-Disciplinary Cases', 'Protest');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('74', 'Non-Disciplinary Cases', 'Reassignment');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('75', 'Non-Disciplinary Cases', 'Recall of the Approval of Appointment');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('76', 'Non-Disciplinary Cases', 'Re-employment');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('77', 'Non-Disciplinary Cases', 'Reinstatement');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('78', 'Non-Disciplinary Cases', 'Removal of Administrative Penalties/Disabilities');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('79', 'Non-Disciplinary Cases', 'Reorganization');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('80', 'Non-Disciplinary Cases', 'Conversion of Position/s from Non-Career to Career');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('81', 'Non-Disciplinary Cases', 'Conversion of Position/s from Career to Non-Career');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('82', 'Non-Disciplinary Cases', 'Revocation of Appointment/s');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('83', 'Non-Disciplinary Cases', 'Secondment');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('84', 'Non-Disciplinary Cases', 'Special Leave for Women');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('85', 'Non-Disciplinary Cases', 'Termination/Separation from the Service');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('86', 'Non-Disciplinary Cases', 'Transfer');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('91', '', 'Reversion to Use of Maiden Name in the Personnel Records');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('92', '', 'Basta');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('93', 'Disciplinary Cases', 'Waray pa');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('94', 'Non-Disciplinary Cases', 'Nangawat');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('95', 'Non-Disciplinary Cases', 'Nanlabay hin balay');
INSERT INTO `cts_taxonomy` (`id`, `type`, `name`) VALUES ('96', 'Non-Disciplinary Cases', 'Waray la bag o na taxonomy');

