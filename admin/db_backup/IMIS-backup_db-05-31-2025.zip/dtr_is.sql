-- Dumping table structure for `dtr_is`

CREATE TABLE `dtr_is` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `division` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `division` (`division`),
  CONSTRAINT `fk_dtr_is_division` FOREIGN KEY (`division`) REFERENCES `dtr_division` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `dtr_is`

INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('1', 'Atty. Gervien T. Berecio', 'OIC Chief Human Resource Specialist', '3', '2025-04-04 03:02:07');
INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('2', 'Pharida Q. Aurelia', 'Director II', '8', '2025-03-10 05:01:59');
INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('3', 'Banello P. Gabon, Ph.D', 'Chief Human Resource Specialist', '4', '2025-03-10 06:34:37');
INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('5', 'Atty. Gervien T. Berecio', 'OIC-Chief Human Resource Specialist', '5', '2025-03-10 06:36:19');
INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('8', 'Jay M. Merelos', 'Chief Human Resource Specialist', '1', '2025-03-11 07:37:59');
INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('12', 'Cristy Joy Q. Macasil', 'Chief Human Resource Specialist', '2', '2025-03-13 09:47:24');
INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('13', 'Atty. Jean T. Balledo', 'Attorney VI', '9', '2025-03-25 10:15:33');
INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('15', 'Ma. Natividad L. Costibolo', 'Director II', '7', '2025-03-25 10:18:14');
INSERT INTO `dtr_is` (`id`, `name`, `position`, `division`, `timestamp`) VALUES ('25', 'Eleonor B. Garcia', 'Chief Human Resource Specialist', '6', '2025-04-21 08:25:09');

