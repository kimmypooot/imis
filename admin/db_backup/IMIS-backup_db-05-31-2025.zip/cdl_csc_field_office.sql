-- Dumping table structure for `cdl_csc_field_office`

CREATE TABLE `cdl_csc_field_office` (
  `cdl_csc_field_office_id` int(11) NOT NULL AUTO_INCREMENT,
  `cdl_csc_field_office_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cdl_csc_field_office_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `cdl_csc_field_office`

INSERT INTO `cdl_csc_field_office` (`cdl_csc_field_office_id`, `cdl_csc_field_office_name`) VALUES ('1', 'Leyte I');
INSERT INTO `cdl_csc_field_office` (`cdl_csc_field_office_id`, `cdl_csc_field_office_name`) VALUES ('2', 'Leyte II');
INSERT INTO `cdl_csc_field_office` (`cdl_csc_field_office_id`, `cdl_csc_field_office_name`) VALUES ('3', 'Biliran');
INSERT INTO `cdl_csc_field_office` (`cdl_csc_field_office_id`, `cdl_csc_field_office_name`) VALUES ('4', 'Southern Leyte');
INSERT INTO `cdl_csc_field_office` (`cdl_csc_field_office_id`, `cdl_csc_field_office_name`) VALUES ('5', 'Samar');
INSERT INTO `cdl_csc_field_office` (`cdl_csc_field_office_id`, `cdl_csc_field_office_name`) VALUES ('6', 'Eastern Samar');
INSERT INTO `cdl_csc_field_office` (`cdl_csc_field_office_id`, `cdl_csc_field_office_name`) VALUES ('7', 'Northern Samar');
INSERT INTO `cdl_csc_field_office` (`cdl_csc_field_office_id`, `cdl_csc_field_office_name`) VALUES ('8', 'Western Leyte');

