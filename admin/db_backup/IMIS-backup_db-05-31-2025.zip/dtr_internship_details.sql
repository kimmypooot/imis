-- Dumping table structure for `dtr_internship_details`

CREATE TABLE `dtr_internship_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `intern` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `course` varchar(255) NOT NULL,
  `target_hours` int(11) NOT NULL,
  `date_started` date NOT NULL,
  `date_ended` date DEFAULT NULL,
  `date_moa` date DEFAULT NULL,
  `date_agreement` date DEFAULT NULL,
  `poa` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_intern_id_1` (`intern`),
  KEY `fk_intern_university_1` (`school`),
  CONSTRAINT `fk_intern_id1` FOREIGN KEY (`intern`) REFERENCES `dtr_interns` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `dtr_internship_details`

INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('1', '1', '1', 'Bachelor Of Science in Information Technology', '486', '2025-02-13', NULL, '0000-00-00', '0000-00-00', '1', '2025-03-18 00:59:55');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('2', '2', '1', 'Bachelor of Science in Information Technology', '486', '2025-02-13', '2025-05-29', '0000-00-00', '0000-00-00', '1', '2025-03-18 01:01:00');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('3', '3', '1', 'Bachelor of Science in Information Technology', '486', '2025-02-13', NULL, '0000-00-00', '0000-00-00', '1', '2025-03-18 01:05:51');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('4', '6', '1', 'Bachelor of Science in Information Technology', '486', '2025-02-13', '2025-05-29', '0000-00-00', '0000-00-00', '1', '2025-03-18 01:09:47');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('5', '4', '1', 'Bachelor of Science in Information Technology', '486', '2025-02-13', '2025-05-29', NULL, NULL, '1', '2025-04-23 07:38:01');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('7', '7', '1', 'Bachelor of Science in Information Technology', '486', '2025-02-13', NULL, '0000-00-00', '0000-00-00', '1', '2025-03-18 01:11:36');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('14', '14', '6', 'Bachelor of Public Administration', '400', '2025-02-03', NULL, '2024-08-27', '2024-08-27', '1', '2025-04-02 03:55:00');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('16', '16', '6', 'Bachelor of Public Administration', '400', '2025-02-03', NULL, '2024-08-27', '2024-08-27', '4', '2025-04-03 02:28:58');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('17', '17', '6', 'Bachelor of Public Administration', '400', '2025-02-03', '2025-05-29', '2024-08-27', '2024-08-27', '2', '2025-04-03 02:35:21');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('18', '18', '6', 'Bachelor of Public Administration', '400', '2025-02-03', NULL, '2024-08-27', '2024-08-27', '6', '2025-04-03 03:15:30');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('25', '25', '1', 'Bachelor of Science in Economics ', '400', '2025-02-24', '2025-05-16', NULL, NULL, '8', '2025-04-28 09:58:44');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('26', '26', '1', 'Bachelor Science in Economics', '400', '2025-02-24', '2025-05-16', NULL, NULL, '8', '2025-04-30 09:16:30');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('27', '27', '1', 'Bachelor of Science in Economics ', '400', '2025-02-24', '2025-05-23', NULL, NULL, '7', '2025-05-01 23:54:18');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('28', '28', '1', 'BACHELOR OF SCIENCE IN ECONOMICS', '400', '2025-02-24', '2025-05-23', NULL, NULL, '7', '2025-05-04 12:49:47');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('29', '29', '6', 'Bachelor of Public Administration', '400', '2025-02-03', NULL, NULL, NULL, '7', '2025-05-05 05:14:45');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('30', '31', '1', 'BS Economics', '400', '2025-02-24', '2025-05-29', NULL, NULL, '8', '2025-05-06 11:10:22');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('31', '32', '1', 'Bachelor of Science in Economics', '400', '2025-02-24', '2025-05-29', NULL, NULL, '8', '2025-05-08 00:44:41');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('32', '33', '7', 'BACHELOR OF ARTS IN POLITICAL SCIENCE', '200', '2025-05-26', NULL, NULL, NULL, '3', '2025-05-19 07:58:57');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('33', '34', '7', 'Bachelor of Arts in Political Science', '200', '2025-05-26', NULL, NULL, NULL, '1', '2025-05-21 07:42:06');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('35', '36', '7', 'Bachelor of Science in Management', '200', '2025-05-26', NULL, NULL, NULL, '7', '2025-05-26 12:15:40');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('36', '37', '7', 'Bachelor of Science in Management', '200', '2025-05-26', NULL, NULL, NULL, '5', '2025-05-27 09:41:26');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('37', '38', '7', 'Bachelor of Science in Management', '200', '2025-05-26', NULL, NULL, NULL, '8', '2025-05-27 15:41:47');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('38', '39', '7', 'BACHELOR OF SCIENCE IN MANAGEMENT', '200', '2025-05-26', NULL, NULL, NULL, '7', '2025-05-28 03:20:19');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('39', '40', '7', 'Bachelor of Science in Management', '200', '2025-05-26', NULL, NULL, NULL, '7', '2025-05-29 02:56:16');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('40', '41', '7', 'Bachelor of Science in Management', '200', '2025-05-26', NULL, NULL, NULL, '8', '2025-05-29 03:13:22');
INSERT INTO `dtr_internship_details` (`id`, `intern`, `school`, `course`, `target_hours`, `date_started`, `date_ended`, `date_moa`, `date_agreement`, `poa`, `timestamp`) VALUES ('46', '47', '7', 'Bachelor of Science in Management', '200', '2025-05-26', NULL, NULL, NULL, '6', '2025-05-30 07:59:44');

