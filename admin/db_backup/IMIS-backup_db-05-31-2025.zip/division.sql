-- Dumping table structure for `division`

CREATE TABLE `division` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `division_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `division`

INSERT INTO `division` (`id`, `division_name`) VALUES ('1', 'Human Resource Division');
INSERT INTO `division` (`id`, `division_name`) VALUES ('2', 'Public Assistance and Liaison Division');
INSERT INTO `division` (`id`, `division_name`) VALUES ('3', 'Examination Services Division');
INSERT INTO `division` (`id`, `division_name`) VALUES ('4', ' Policies and Systems Evaluation Division');
INSERT INTO `division` (`id`, `division_name`) VALUES ('5', 'Anti Red Tape Unit');
INSERT INTO `division` (`id`, `division_name`) VALUES ('6', 'Management Services Division');
INSERT INTO `division` (`id`, `division_name`) VALUES ('7', 'CSC Field Office - Leyte I, Tacloban City');
INSERT INTO `division` (`id`, `division_name`) VALUES ('8', 'CSC Field Office - Leyte II, Palo, Leyte');
INSERT INTO `division` (`id`, `division_name`) VALUES ('9', 'Legal Services Division');

