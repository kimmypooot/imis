-- Dumping table structure for `proctad_designation`

CREATE TABLE `proctad_designation` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `designation` varchar(254) NOT NULL,
  `fee` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_designation`

INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('1', 'Room Examiner', '1400');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('2', 'Proctor', '1400');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('3', 'Supervising Examiner', '1700');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('4', 'Alternative Test Administrator', '750');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('5', 'Chief Examiner for Administration', '1900');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('6', 'Chief Examiner for Investigation', '1900');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('7', 'Room Examiner - Retrieval', '1400');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('8', 'REC Chairperson', '2400');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('9', 'REC Co-Chairperson', '2400');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('10', 'REC Member', '1900');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('11', 'LEC Chairperson', '2100');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('12', 'LEC Co-Chairperson', '2100');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('13', 'LEC Member', '1700');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('14', 'Paymaster', '1400');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('15', 'Helper', '1000');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('16', 'Driver', '1000');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('17', 'HMT', '');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('18', 'PNP Personnel', '1400');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('19', 'Janitor', '1000');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('20', 'Security Guard (School)', '1000');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('21', 'School Coordinator', '1900');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('22', 'Room Inspector', '1400');
INSERT INTO `proctad_designation` (`id`, `designation`, `fee`) VALUES ('23', 'Buffer Test Administrator', '750');

