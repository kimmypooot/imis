-- Dumping table structure for `trip_records`

CREATE TABLE `trip_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `date` date NOT NULL,
  `input_odo` int(11) NOT NULL,
  `add_fuel` int(11) NOT NULL,
  `final_odo` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `car_id` int(11) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_car_id` (`car_id`),
  KEY `fk_record_user` (`user`),
  CONSTRAINT `fk_record_user` FOREIGN KEY (`user`) REFERENCES `trip_drivers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `trip_records`

INSERT INTO `trip_records` (`id`, `user`, `date`, `input_odo`, `add_fuel`, `final_odo`, `status`, `car_id`, `remarks`, `timestamp`) VALUES ('1', '8', '2025-05-23', '320', '5', '330', 'Completed', '1', '', '2025-05-23 06:53:31');

