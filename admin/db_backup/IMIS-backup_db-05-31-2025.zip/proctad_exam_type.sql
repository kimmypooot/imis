-- Dumping table structure for `proctad_exam_type`

CREATE TABLE `proctad_exam_type` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `exam_type` varchar(64) NOT NULL,
  `exam_type_code` varchar(36) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_exam_type`

INSERT INTO `proctad_exam_type` (`id`, `exam_type`, `exam_type_code`) VALUES ('1', 'Career Service Professional', 'PROF');
INSERT INTO `proctad_exam_type` (`id`, `exam_type`, `exam_type_code`) VALUES ('2', 'Career Service Subprofessional', 'SUBPROF');
INSERT INTO `proctad_exam_type` (`id`, `exam_type`, `exam_type_code`) VALUES ('3', 'Fire Officer Examination', 'FOE');
INSERT INTO `proctad_exam_type` (`id`, `exam_type`, `exam_type_code`) VALUES ('4', 'Penology Officer Examination', 'POE');
INSERT INTO `proctad_exam_type` (`id`, `exam_type`, `exam_type_code`) VALUES ('5', 'Basic Competency on Local Treasury Examination', 'BCLTE');
INSERT INTO `proctad_exam_type` (`id`, `exam_type`, `exam_type_code`) VALUES ('6', 'Intermediate Competency on Local Treasury Examination', 'ICLTE');

