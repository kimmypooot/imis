-- Dumping table structure for `db_preference`

CREATE TABLE `db_preference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certno` varchar(64) NOT NULL,
  `issuedate` varchar(24) NOT NULL,
  `effdate` varchar(24) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `mname` varchar(24) NOT NULL,
  `extname` varchar(24) NOT NULL,
  `bdate` varchar(24) NOT NULL,
  `pbirth` varchar(64) NOT NULL,
  `picture` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `db_preference` is empty

