-- Dumping table structure for `proctad_ta_record`

CREATE TABLE `proctad_ta_record` (
  `record_id` int(12) NOT NULL AUTO_INCREMENT,
  `ta_id` int(12) NOT NULL,
  `exam_type_id` int(12) NOT NULL,
  `exam_date_id` int(12) NOT NULL,
  `testing_center_id` int(12) NOT NULL,
  `school_id` int(12) NOT NULL,
  `designation` int(12) NOT NULL,
  `time_in` varchar(12) NOT NULL,
  `evaluation` int(12) NOT NULL,
  PRIMARY KEY (`record_id`),
  KEY `idx_ta_id` (`ta_id`),
  KEY `idx_exam_type_id` (`exam_type_id`),
  KEY `idx_exam_date_id` (`exam_date_id`),
  KEY `idx_testing_center_id` (`testing_center_id`),
  KEY `fk_schools_fo_id` (`school_id`),
  KEY `fk_designation` (`designation`),
  CONSTRAINT `fk_designation` FOREIGN KEY (`designation`) REFERENCES `proctad_designation` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_exam_date_id` FOREIGN KEY (`exam_date_id`) REFERENCES `proctad_exam_dates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_exam_type_id` FOREIGN KEY (`exam_type_id`) REFERENCES `proctad_exam_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_schools_fo_id` FOREIGN KEY (`school_id`) REFERENCES `proctad_schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ta_id` FOREIGN KEY (`ta_id`) REFERENCES `proctad_testadmin` (`ta_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_testing_center_id` FOREIGN KEY (`testing_center_id`) REFERENCES `proctad_fo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_ta_record`

INSERT INTO `proctad_ta_record` (`record_id`, `ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `school_id`, `designation`, `time_in`, `evaluation`) VALUES ('1', '58', '3', '2', '1', '1', '1', '', '0');
INSERT INTO `proctad_ta_record` (`record_id`, `ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `school_id`, `designation`, `time_in`, `evaluation`) VALUES ('2', '58', '1', '1', '1', '1', '1', '', '0');
INSERT INTO `proctad_ta_record` (`record_id`, `ta_id`, `exam_type_id`, `exam_date_id`, `testing_center_id`, `school_id`, `designation`, `time_in`, `evaluation`) VALUES ('3', '10', '1', '1', '2', '10', '1', '', '0');

