-- Dumping table structure for `psed_spear_ld`

CREATE TABLE `psed_spear_ld` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `psed_spear_year` varchar(12) NOT NULL,
  `psed_spear_details` varchar(64) NOT NULL,
  `psed_spear_nohours` varchar(12) NOT NULL,
  `psed_spear_type` varchar(64) NOT NULL,
  `psed_spear_nametrng` varchar(512) NOT NULL,
  `psed_spear_venue` varchar(512) NOT NULL,
  `psed_spear_nopers` varchar(12) NOT NULL,
  `psed_spear_budget` varchar(12) NOT NULL,
  `psed_spear_expenses` varchar(12) NOT NULL,
  `psed_spear_netincome` varchar(12) NOT NULL,
  `psed_spear_file` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `psed_spear_ld` is empty

