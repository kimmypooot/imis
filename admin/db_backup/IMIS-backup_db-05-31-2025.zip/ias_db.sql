-- Dumping table structure for `ias_db`

CREATE TABLE `ias_db` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `type` varchar(124) NOT NULL,
  `date_issuance` varchar(36) NOT NULL,
  `file_name` varchar(512) NOT NULL,
  `file_path` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `ias_db` is empty

