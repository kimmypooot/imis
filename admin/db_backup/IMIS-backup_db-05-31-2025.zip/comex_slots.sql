-- Dumping table structure for `comex_slots`

CREATE TABLE `comex_slots` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `date` varchar(128) NOT NULL,
  `type_exam` varchar(64) NOT NULL,
  `total_slots` varchar(6) NOT NULL,
  `no_slots` varchar(6) NOT NULL,
  `acct_date` varchar(12) NOT NULL,
  `examinee_guide` varchar(254) NOT NULL,
  `remarks` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `comex_slots`

INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('4', '2024-03-12', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('5', '2024-03-14', 'Professional', '27', '0', '2024', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('6', '2024-03-19', 'Professional', '27', '0', '2024', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('7', '2024-03-21', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('8', '2024-04-02', 'Subprofessional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('9', '2024-04-04', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('10', '2024-04-16', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('11', '2024-04-18', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('12', '2024-04-23', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('13', '2024-04-25', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('14', '2024-04-30', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('15', '2024-05-02', 'Professional', '27', '0', '', '0', 'CANCELLED - Resched to May 17, 2024');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('16', '2024-05-07', 'Professional', '27', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('17', '2024-05-14', 'Subprofessional', '27', '2', '', '0', 'CANCELLED - Resched to July 10 2024');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('18', '2024-05-16', 'Professional', '27', '2', '', '0', 'CANCELLED - Resched to July 11, 2024');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('19', '2024-06-11', 'Professional', '27', '0', '', '0', 'CANCELLED');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('20', '2024-06-13', 'Professional', '27', '0', '', '0', 'OK');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('21', '2024-07-02', 'Professional', '29', '3', '', '0', 'CANCELLED');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('22', '2024-07-04', 'Professional', '29', '1', '', '0', 'CANCELLED');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('23', '2024-07-09', 'Professional', '29', '0', '', '0', 'CANCELLED ');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('24', '2024-08-27', 'Professional', '29', '0', '', '0', 'CANCELLED');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('25', '2024-08-29', 'Professional', '29', '3', '', '0', 'CANCELLED');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('26', '2024-09-10', 'Professional', '29', '0', '', '0', 'CANCELLED');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('27', '2024-09-12', 'Professional', '29', '0', '', '0', 'OK');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('28', '2024-10-01', 'Subprofessional', '29', '2', '', '0', 'OK / 34 ACTUAL');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('29', '2024-10-03', 'Professional', '48', '1', '', '0', 'OK / 36 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('30', '2024-10-08', 'Professional', '48', '1', '', '0', '37 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('31', '2024-10-10', 'Professional', '48', '0', '', '0', '45 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('32', '2024-10-15', 'Professional', '48', '0', '', '0', '46 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('33', '2024-10-17', 'Professional', '48', '0', '', '0', '39 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('34', '2024-10-29', 'Professional', '48', '0', '', '0', '38 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('35', '2024-10-31', 'Professional', '48', '0', '', '0', 'Deferred to 7 November 2024');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('36', '2024-11-12', 'Subprofessional', '48', '0', '', '0', 'OK - 46 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('37', '2024-11-14', 'Professional', '48', '0', '', '0', '48 ACTUAL EXAMINEES / 9 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('38', '2024-11-19', 'Professional', '48', '0', '', '0', '48 ACTUAL EXAMINEES / 4 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('39', '2024-11-21', 'Professional', '48', '0', '', '0', '47 ACTUAL EXAMINEES / 3 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('40', '2024-11-26', 'Professional', '48', '0', '', '0', '47 ACTUAL EXAMINEES / 0 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('41', '2024-05-17', 'Professional', '20', '1', '2024-05-16', '0', 'OK');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('43', '2024-10-18', 'Professional', '48', '0', '', '0', '36 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('44', '2024-11-06', 'Professional', '48', '0', '', '0', 'CANCELLED - Rescheduled to 8 Nov 2024');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('46', '2024-11-28', 'Professional', '48', '0', '', '0', '49 ACTUAL EXAMINEES / 1 PASSER');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('47', '2024-11-05', 'Subprofessional', '48', '2', '', '0', '43 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('48', '2024-11-07', 'Professional', '48', '0', '2024-11-06', '0', 'Updated schedule from 31 October 2024 // OK-40 Actual Examinees');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('49', '2024-11-08', 'Professional', '49', '1', '', '0', 'FROM 6 November 2024 | 39 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('50', '2025-01-07', 'Professional', '48', '42', '', '0', '7 ACTUAL EXAMINEES | 1 PASSER');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('51', '2025-01-09', 'Professional', '48', '1', '', '0', '47 ACTUAL EXAMINEES');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('52', '2025-03-11', 'Subprofessional', '48', '20', '', '0', '26 ACTUAL | 4 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('53', '2025-03-13', 'Professional', '48', '0', '', '0', '42 ACTUAL | 5 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('54', '2025-03-18', 'Professional', '48', '10', '', '0', '38 ACTUAL | 3 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('55', '2025-03-20', 'Professional', '48', '-49', '', '0', 'CANCELLED per ERPO Memo No. 0286');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('56', '2025-03-25', 'Professional', '48', '18', '', '0', '28 ACTUAL | 3 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('57', '2025-03-27', 'Professional', '48', '20', '', '0', '25 REGISTERED | 23 ACTUAL | 4 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('58', '2025-04-01', 'Subprofessional', '48', '0', '', '0', 'Rescheduled to 19 June 2025 per ERPO Memo No. 0339, s. 2025');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('59', '2025-04-03', 'Professional', '48', '31', '', '0', '18 REGISTERED | 15 ACTUAL | 1 PASSER');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('60', '2025-04-08', 'Professional', '48', '22', '', '0', '24 REGISTERED | 20 ACTUAL | 1 PASSER');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('61', '2025-04-10', 'Professional', '48', '31', '', '0', '17 REGISTERED | 14 ACTUAL | 2 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('62', '2025-04-22', 'Professional', '48', '30', '', '0', '18 REGISTERED | 16 ACTUAL | 0 PASSER');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('63', '2025-04-24', 'Professional', '48', '24', '', '0', '21 REGISTERED | 20 ACTUAL | 1 PASSER');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('64', '2025-04-29', 'Professional', '48', '22', '', '0', '23 REGISTERED | 21 ACTUAL | 6 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('65', '2025-05-06', 'Professional', '48', '33', '', '0', '10 REGISTERED | 8 ACTUAL | 0 PASSER');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('66', '2025-05-08', 'Professional', '48', '14', '', '0', '31 REGISTERED | 31 ACTUAL | 2 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('67', '2025-05-13', 'Professional', '49', '21', '', '0', '21 REGISTERED | 19 ACTUAL | 5 PASSERS');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('68', '2025-05-15', 'Professional', '49', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('69', '2025-06-10', 'Professional', '49', '0', '', '0', '');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('70', '2025-06-19', 'Subprofessional', '49', '0', '', '0', 'ERPO Memo No. 0339, s. 2025');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('71', '2025-06-17', 'Professional', '49', '23', '', '0', 'ERPO Memo No. 0286, s. 2025');
INSERT INTO `comex_slots` (`id`, `date`, `type_exam`, `total_slots`, `no_slots`, `acct_date`, `examinee_guide`, `remarks`) VALUES ('72', '2025-12-25', 'Professional', '50', '49', '', '0', 'FOR TESTING PURPOSES ONLY');

