-- Dumping table structure for `dtr_interns_pslip`

CREATE TABLE `dtr_interns_pslip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dtr_id` int(11) NOT NULL,
  `time_out` time NOT NULL,
  `time_in` time NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_dtr_id` (`dtr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `dtr_interns_pslip`

INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('1', '556', '12:05:00', '14:20:00', '2025-04-15 08:11:47');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('8', '120', '09:00:00', '10:00:00', '2025-03-30 09:56:00');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('9', '219', '10:00:00', '11:00:00', '2025-03-30 09:59:51');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('10', '536', '09:00:00', '10:00:00', '2025-04-21 02:48:26');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('13', '1185', '10:10:00', '11:23:00', '2025-05-14 00:22:17');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('14', '1179', '10:10:00', '11:10:00', '2025-05-14 00:22:55');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('15', '833', '10:05:00', '11:30:00', '2025-05-14 00:41:30');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('17', '1122', '10:10:00', '11:23:00', '2025-05-14 04:00:11');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('18', '1095', '09:00:00', '10:00:00', '2025-05-14 04:02:05');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('22', '2', '12:00:00', '15:00:00', '2025-05-15 03:25:49');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('28', '1192', '08:30:00', '11:45:00', '2025-05-16 06:23:48');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('29', '1234', '09:00:00', '10:00:00', '2025-05-16 07:18:08');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('31', '40', '13:00:00', '14:18:00', '2025-05-20 06:21:13');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('35', '1661', '12:00:00', '07:26:00', '2025-05-29 02:59:03');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('37', '1662', '12:00:00', '07:36:00', '2025-05-29 03:05:11');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('38', '1662', '17:00:00', '12:56:00', '2025-05-29 03:05:54');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('39', '1663', '12:00:00', '07:11:00', '2025-05-29 03:16:46');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('40', '1663', '17:00:00', '00:55:00', '2025-05-30 03:17:01');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('43', '1664', '12:00:00', '07:24:00', '2025-05-30 03:18:02');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('50', '1664', '17:00:00', '12:55:00', '2025-05-30 03:18:35');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('54', '1721', '12:00:00', '07:16:00', '2025-05-30 04:59:04');
INSERT INTO `dtr_interns_pslip` (`id`, `dtr_id`, `time_out`, `time_in`, `timestamp`) VALUES ('58', '1721', '17:00:00', '12:49:00', '2025-05-30 08:15:20');

