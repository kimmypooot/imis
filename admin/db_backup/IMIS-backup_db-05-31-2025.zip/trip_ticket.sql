-- Dumping table structure for `trip_ticket`

CREATE TABLE `trip_ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_number` varchar(255) NOT NULL,
  `user` int(11) NOT NULL,
  `car` int(11) NOT NULL,
  `passenger` int(11) NOT NULL,
  `place` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `departure_time` time DEFAULT NULL,
  `arrival_time` time DEFAULT NULL,
  `distance` int(11) NOT NULL,
  `balance_tank` int(11) NOT NULL,
  `issued_stock` int(11) NOT NULL,
  `purchased_fuel` int(11) NOT NULL,
  `total_fuel` int(11) NOT NULL,
  `deduct_fuel` int(11) NOT NULL,
  `end_balance_tank` int(11) NOT NULL,
  `gear_oil` int(11) NOT NULL,
  `lube_oil` int(11) NOT NULL,
  `grease_oil` int(11) NOT NULL,
  `start_odo` int(11) NOT NULL,
  `end_odo` int(11) NOT NULL,
  `distance_travelled` int(11) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `trip_ticket`

INSERT INTO `trip_ticket` (`id`, `ticket_number`, `user`, `car`, `passenger`, `place`, `purpose`, `departure_time`, `arrival_time`, `distance`, `balance_tank`, `issued_stock`, `purchased_fuel`, `total_fuel`, `deduct_fuel`, `end_balance_tank`, `gear_oil`, `lube_oil`, `grease_oil`, `start_odo`, `end_odo`, `distance_travelled`, `remarks`, `timestamp`, `status`) VALUES ('1', '', '8', '0', '0', '', '', '00:00:00', '00:00:00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '2025-05-23 06:59:01', '');
INSERT INTO `trip_ticket` (`id`, `ticket_number`, `user`, `car`, `passenger`, `place`, `purpose`, `departure_time`, `arrival_time`, `distance`, `balance_tank`, `issued_stock`, `purchased_fuel`, `total_fuel`, `deduct_fuel`, `end_balance_tank`, `gear_oil`, `lube_oil`, `grease_oil`, `start_odo`, `end_odo`, `distance_travelled`, `remarks`, `timestamp`, `status`) VALUES ('2', '', '8', '0', '0', '', '', '00:00:00', '00:00:00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '2025-05-23 07:02:39', '');
INSERT INTO `trip_ticket` (`id`, `ticket_number`, `user`, `car`, `passenger`, `place`, `purpose`, `departure_time`, `arrival_time`, `distance`, `balance_tank`, `issued_stock`, `purchased_fuel`, `total_fuel`, `deduct_fuel`, `end_balance_tank`, `gear_oil`, `lube_oil`, `grease_oil`, `start_odo`, `end_odo`, `distance_travelled`, `remarks`, `timestamp`, `status`) VALUES ('3', '', '8', '0', '0', '', '', '00:00:00', '00:00:00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '2025-05-23 07:05:24', '');
INSERT INTO `trip_ticket` (`id`, `ticket_number`, `user`, `car`, `passenger`, `place`, `purpose`, `departure_time`, `arrival_time`, `distance`, `balance_tank`, `issued_stock`, `purchased_fuel`, `total_fuel`, `deduct_fuel`, `end_balance_tank`, `gear_oil`, `lube_oil`, `grease_oil`, `start_odo`, `end_odo`, `distance_travelled`, `remarks`, `timestamp`, `status`) VALUES ('4', '', '8', '0', '0', '', '', '00:00:00', '00:00:00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '2025-05-23 07:10:19', '');
INSERT INTO `trip_ticket` (`id`, `ticket_number`, `user`, `car`, `passenger`, `place`, `purpose`, `departure_time`, `arrival_time`, `distance`, `balance_tank`, `issued_stock`, `purchased_fuel`, `total_fuel`, `deduct_fuel`, `end_balance_tank`, `gear_oil`, `lube_oil`, `grease_oil`, `start_odo`, `end_odo`, `distance_travelled`, `remarks`, `timestamp`, `status`) VALUES ('5', '', '8', '0', '0', '', '', '00:00:00', '00:00:00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '2025-05-23 07:12:45', '');
INSERT INTO `trip_ticket` (`id`, `ticket_number`, `user`, `car`, `passenger`, `place`, `purpose`, `departure_time`, `arrival_time`, `distance`, `balance_tank`, `issued_stock`, `purchased_fuel`, `total_fuel`, `deduct_fuel`, `end_balance_tank`, `gear_oil`, `lube_oil`, `grease_oil`, `start_odo`, `end_odo`, `distance_travelled`, `remarks`, `timestamp`, `status`) VALUES ('6', 'Test', '8', '0', '0', '', '', '00:00:00', '00:00:00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '2025-05-23 07:13:04', '');
INSERT INTO `trip_ticket` (`id`, `ticket_number`, `user`, `car`, `passenger`, `place`, `purpose`, `departure_time`, `arrival_time`, `distance`, `balance_tank`, `issued_stock`, `purchased_fuel`, `total_fuel`, `deduct_fuel`, `end_balance_tank`, `gear_oil`, `lube_oil`, `grease_oil`, `start_odo`, `end_odo`, `distance_travelled`, `remarks`, `timestamp`, `status`) VALUES ('7', 'Test', '8', '1', '1', 'Test', 'Test', '12:00:00', '12:00:00', '1', '1', '20', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 'Test', '2025-05-23 07:13:21', '');

