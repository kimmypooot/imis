-- Dumping table structure for `db_onsa_prof`

CREATE TABLE `db_onsa_prof` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `lname` varchar(254) NOT NULL,
  `fname` varchar(254) NOT NULL,
  `ext_name` varchar(254) NOT NULL,
  `mname` varchar(254) NOT NULL,
  `minitial` varchar(254) NOT NULL,
  `school` varchar(124) NOT NULL,
  `roomno` varchar(3) NOT NULL,
  `birth_date` varchar(124) NOT NULL,
  `birth_place` varchar(254) NOT NULL,
  `pwd_status` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `db_onsa_prof` is empty

