-- Dumping table structure for `sets_type`

CREATE TABLE `sets_type` (
  `id` int(11) NOT NULL,
  `type` varchar(12) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `sets_type` is empty

