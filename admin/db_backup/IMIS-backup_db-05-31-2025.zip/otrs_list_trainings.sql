-- Dumping table structure for `otrs_list_trainings`

CREATE TABLE `otrs_list_trainings` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` varchar(254) NOT NULL,
  `type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for `otrs_list_trainings`

INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('1', 'Supervisory Development Course (SDC), Track 1', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('2', 'Supervisory Development Course (SDC), Tracks 2 and 3', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('3', 'Supervisory Development Program (SDP), Modules 1 and 2', 'Face to Face');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('4', 'Supervisory Development Program (SDP), Modules 3 and 4', 'Face to Face');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('5', 'Supervisory Development Program (SDP), Module 5', 'Face to Face');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('6', 'Basic Customer Service Skills (BCSS)', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('7', 'Orientation-Workshop on the Omnibus Rules on Appointments and Other Human Resource Actions (ORA OHRA)', 'Face to Face');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('8', 'Public Service Values Program (PSVP)', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('9', 'Leave Administration Course for Effectiveness (LACE)', 'Face to Face');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('10', 'Seminar-Workshop on Administrative Justice (SWAJ) and Capability Building for Committee for Decorum and Investigation (CODI)', 'Face to Face');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('11', '2024 Service Excellence Summit for Leaders (SESL) - Waitlist', 'Face to Face');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('12', 'Virtual GEDSI Forum', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('13', 'Seminar on Completed Staff Work', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('14', 'RSP for PRIME-HRM Level 2', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('15', 'Seminar-Workshop on Administrative Justice (SWAJ) and Capability Building for Committee for Decorum and Investigation (CODI)', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('16', 'Values Orientation Workshop (VOW)', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('17', 'Seminar-Workshop on Coaching and Mentoring', 'Online');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('18', 'Fostering Unity and Efficiency: Orientation on the 2024 Implementing Rules and Regulations of E.O. 180 for Public Sector Employees Organizations (PSEOs) in Eastern Visayas', 'Face to Face');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('19', 'PM for PRIME-HRM  Level 2', '');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('20', 'Financial Education Program', '');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('21', '2025 Conversations with Local Leaders in Eastern Visayas (CLLEV)', '');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('22', 'L&D for PRIME-HRM  Level 2', '');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('23', 'Mental Health Seminar', '');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('24', 'R&R for PRIME-HRM  Level 2', '');
INSERT INTO `otrs_list_trainings` (`id`, `name`, `type`) VALUES ('25', 'Capacity Building for Committee Members of Grievance, PRAISE and HRMPSB', '');

