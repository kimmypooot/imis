-- Dumping table structure for `appt_archive`

CREATE TABLE `appt_archive` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `year` varchar(6) NOT NULL,
  `month` varchar(12) NOT NULL,
  `fo` varchar(34) NOT NULL,
  `filepath_moa` varchar(512) NOT NULL,
  `moa_date` varchar(64) NOT NULL,
  `moa_efficiency` varchar(12) NOT NULL,
  `moa_timeliness` varchar(12) NOT NULL,
  `filepath_ipmr` varchar(512) NOT NULL,
  `ipmr_date` varchar(64) NOT NULL,
  `ipmr_efficiency` varchar(12) NOT NULL,
  `ipmr_timeliness` varchar(12) NOT NULL,
  `filepath_mrap` varchar(512) NOT NULL,
  `mrap_date` varchar(64) NOT NULL,
  `mrap_efficiency` varchar(12) NOT NULL,
  `mrap_timeliness` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `appt_archive` is empty

