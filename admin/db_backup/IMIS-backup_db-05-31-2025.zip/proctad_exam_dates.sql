-- Dumping table structure for `proctad_exam_dates`

CREATE TABLE `proctad_exam_dates` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `exam_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `proctad_exam_dates`

INSERT INTO `proctad_exam_dates` (`id`, `exam_date`) VALUES ('1', '2025-08-10');
INSERT INTO `proctad_exam_dates` (`id`, `exam_date`) VALUES ('2', '2025-03-09');

