-- Dumping table structure for `db_bns`

CREATE TABLE `db_bns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certno` varchar(64) NOT NULL,
  `issuedate` varchar(24) NOT NULL,
  `effdate` varchar(24) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `mname` varchar(24) NOT NULL,
  `extname` varchar(24) NOT NULL,
  `bdate` varchar(24) NOT NULL,
  `pbirth` varchar(64) NOT NULL,
  `picture` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `db_bns`

INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('90', '120108110001', '28-Jul-11', '05-Jun-11', 'TABARES', 'CHRISTY', 'PLACIDO', '', '16-Jun-74', 'CEBU CITY', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('91', '120108110002', '21-Nov-11', '21-Nov-11', 'CATUDIO', 'JEREMY', 'CANALES', '', '26-Dec-78', 'MAYDOLONG, EASTERN SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('92', '120108120001', '02-Feb-12', '12-Jan-12', 'CAALIM', 'GILDA', 'ASIS', '', '07-Sep-71', 'MARIPIPI, BILIRAN', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('93', '120108150001', '07-Sep-15', '07-Sep-15', 'DOCALLOS', 'CORNELIA', 'MONACAR', '', '29-Nov-67', 'ALMERIA, BILIRAN', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('94', '120108160001', '22-Dec-16', '22-Dec-16', 'DONCERAS', 'NITA', 'MUGAR', '', '06-Jul-65', 'ORAS, EASTERN SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('95', '120108160002', '22-Dec-16', '22-Dec-16', 'PORTON', 'EVALYN', 'PITPIT', '', '29-Oct-77', 'ORAS, EASTERN SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('96', '120108160003', '22-Dec-16', '22-Dec-16', 'MONTALLANA', 'MYRA', 'MAISO', '', '17-Aug-79', 'ORAS, EASTERN SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('97', '120108170001', '19-May-17', '18-May-17', 'ROSAL', 'MERCY', 'ADENIR', '', '16-Mar-63', 'OZAMIZ, MISAMIS OCC.', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('98', '120108170002', '28-Jul-17', '27-Jul-17', 'LOMUNTAD', 'MARIA RUTH', 'PACAYRA', '', '23-Feb-80', 'ORAS, EASTERN SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('99', '120108170003', '09-Aug-17', '08-Aug-17', 'NOROMBABA', 'MARIA LINDA', 'MENGOTE', '', '11-Jan-72', 'ORAS, EASTERN SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('100', '120108180001', '26-Nov-18', '26-Nov-18', 'BORILLA', 'GINA', 'BUENO', '', '29-Sep-76', 'TABACO, ALBAY', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('101', '120108220001', '01-Jun-22', '01-Jun-22', 'ERASMO', 'KRESHIA KAY', 'ALBANO', '', '28-Mar-91', 'TARANGNAN, SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('102', '120108220002', '23-Sep-22', '23-Sep-22', 'AREVALO', 'MARVIN', 'LUNGAY', '', '01-Jan-81', 'BAYBAY, LEYTE', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('103', '120108230001', '14-Feb-23', '14-Feb-23', 'LUPIGA', 'JONALYN', 'ABERLA', '', '12-Feb-77', 'MAYDOLONG, EASTERN SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('104', '120108240001', '20-Feb-24', '20-Feb-23', 'BAJE', 'CARINA', 'COSTUNA', '', '19-Jan-81', 'BORONGAN, EASTERN SAMAR', '');
INSERT INTO `db_bns` (`id`, `certno`, `issuedate`, `effdate`, `lname`, `fname`, `mname`, `extname`, `bdate`, `pbirth`, `picture`) VALUES ('105', '120108240002', '11-Jul-24', '11-Jul-24', 'CODOY', 'ROSARIA', 'ABENALES', '', '15-Dec-83', 'MAYDOLONG, EASTERN SAMAR', '');

