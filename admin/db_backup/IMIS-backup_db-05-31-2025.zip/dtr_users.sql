-- Dumping table structure for `dtr_users`

CREATE TABLE `dtr_users` (
  `id` int(11) NOT NULL,
  `dtr_users_fname` varchar(255) NOT NULL,
  `dtr_users_lname` varchar(255) NOT NULL,
  `dtr_users_mi` varchar(255) NOT NULL,
  `dtr_users_school` int(11) NOT NULL,
  `dtr_users_course` varchar(255) NOT NULL,
  `dtr_users_sex` varchar(255) NOT NULL,
  `dtr_users_rnih` varchar(255) NOT NULL,
  `dtr_users_date_started` date NOT NULL,
  `dtr_users_date_ended` date NOT NULL,
  `dtr_users_anih` varchar(255) NOT NULL,
  `dtr_users_dma` date NOT NULL,
  `dtr_users_dia` date NOT NULL,
  `dtr_users_poa` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `pds` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `profile_pic` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `dtr_users` is empty

