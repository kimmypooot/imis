-- Dumping table structure for `sets_returned_documents`

CREATE TABLE `sets_returned_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` int(11) NOT NULL,
  `date_sent` date DEFAULT NULL,
  `date_received` date DEFAULT NULL,
  `remarks` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fK_client_rId` (`client`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table `sets_returned_documents` is empty

