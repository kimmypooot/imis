-- Dumping table structure for `cts_manage_users`

CREATE TABLE `cts_manage_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `ao_number` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ao_number` (`ao_number`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `cts_manage_users`

INSERT INTO `cts_manage_users` (`id`, `user`, `ao_number`) VALUES ('1', '2', '427-S');
INSERT INTO `cts_manage_users` (`id`, `user`, `ao_number`) VALUES ('2', '1', '437-C');
INSERT INTO `cts_manage_users` (`id`, `user`, `ao_number`) VALUES ('3', '46', '437-A');
INSERT INTO `cts_manage_users` (`id`, `user`, `ao_number`) VALUES ('4', '8', '487-A');

